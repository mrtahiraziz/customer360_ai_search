# Tasks

Legend: [x] done · [~] in progress · [ ] todo

## Setup
- [x] Confirm workspace connection (`fe_azure_east`, tahir.aziz@databricks.com)
- [x] Create schema `fe_tahir_aziz.customer360_search`
- [x] uv project (Python 3.12), dependencies
- [x] Create staging volume

## Data
- [x] Synthetic data generator (10k members, 32k orders, 12.6k cases, 34.9k notes)
- [x] Upload + load tables
- [x] Build Gold tables (golden, search_doc, interactions 47.5k chunks, profile, audit) with CDF
- [x] Validate counts and normalization (John Smith / Jon Smyth share soundex J500 S530)

## AI Search
- [x] Create dedicated endpoint `c360-search-ep` (STANDARD)
- [x] Create member index (hybrid) — Delta Sync, `databricks-gte-large-en` (10,000 rows)
- [x] Create interaction index (hybrid) — Delta Sync (47,466 rows)
- [x] Smoke-test member queries (typo, nickname, phone, email, ID, FULL_TEXT typeahead, LLM filters)
- [x] Smoke-test interaction / notes queries and reranker (local + deployed)

## App
- [x] FastAPI backend: router, LLM parser, AI Search + warehouse clients, audit
- [x] React UI: search bar, typeahead, filters, results, match badges, 360 profile
- [x] Run locally and verify in browser (Playwright screenshots)
- [x] Deploy to Databricks Apps (`c360-member-search`), resources registered
- [x] Verify deployed app (health, name/email/phone/NL search, profile, audit rows written by app SP)

## Wrap-up
- [x] Demo script with example queries (DEMO.md)
- [ ] Update architecture doc with what was built
