"""Phrase library for synthetic cases and contact-center notes.

Each category has several paraphrases per section so that semantic search has something to find
("charged twice" vs "duplicate charge" vs "billed two times").
"""

NICKNAMES = {
    "Robert": ["Bob", "Rob", "Bobby", "Robbie"],
    "William": ["Bill", "Will", "Billy"],
    "Elizabeth": ["Liz", "Beth", "Betty", "Lizzie", "Eliza"],
    "Katherine": ["Kate", "Katie", "Kathy", "Kat"],
    "Catherine": ["Cathy", "Kate", "Katie"],
    "Kathryn": ["Kathy", "Kate", "Katie"],
    "Michael": ["Mike", "Mikey"],
    "Jennifer": ["Jen", "Jenny"],
    "Jonathan": ["Jon", "Johnny"],
    "John": ["Jack", "Johnny", "Jon"],
    "Richard": ["Rick", "Rich", "Ricky", "Dick"],
    "Margaret": ["Maggie", "Peggy", "Meg"],
    "James": ["Jim", "Jimmy", "Jamie"],
    "Thomas": ["Tom", "Tommy"],
    "Christopher": ["Chris"],
    "Daniel": ["Dan", "Danny"],
    "Matthew": ["Matt"],
    "Anthony": ["Tony"],
    "Joseph": ["Joe", "Joey"],
    "Patricia": ["Pat", "Patty", "Trish"],
    "Susan": ["Sue", "Suzie"],
    "Deborah": ["Deb", "Debbie"],
    "Steven": ["Steve"],
    "Stephen": ["Steve"],
    "Alexander": ["Alex", "Xander"],
    "Alexandra": ["Alex", "Alexa"],
    "Samantha": ["Sam"],
    "Nicholas": ["Nick"],
    "Rebecca": ["Becky", "Becca"],
    "Jessica": ["Jess", "Jessie"],
    "Victoria": ["Vicky", "Tori"],
    "Benjamin": ["Ben"],
    "Andrew": ["Andy", "Drew"],
    "Edward": ["Ed", "Eddie", "Ted"],
    "Charles": ["Charlie", "Chuck"],
    "Theodore": ["Ted", "Theo"],
    "Abigail": ["Abby"],
    "Isabella": ["Bella", "Izzy"],
    "Jacqueline": ["Jackie"],
    "Timothy": ["Tim", "Timmy"],
    "Gregory": ["Greg"],
    "Kenneth": ["Ken", "Kenny"],
    "Lawrence": ["Larry"],
    "Frederick": ["Fred", "Freddie"],
    "Eleanor": ["Ellie", "Nora"],
    "Madeline": ["Maddie"],
    "Joshua": ["Josh"],
    "Zachary": ["Zach"],
    "Nathaniel": ["Nate", "Nathan"],
    "Francisco": ["Paco", "Frank"],
    "Alejandro": ["Alex", "Alejo"],
    "Jose": ["Pepe"],
    "Maria": ["Mari"],
    "Gabriela": ["Gaby"],
}

# ---------------------------------------------------------------------------
# Case / note categories
# Slots: {amount} {date} {order} {product} {days} {plan_old} {plan_new} {device}
# ---------------------------------------------------------------------------
CATEGORIES = {
    "billing_dispute": {
        "weight": 18,
        "negative": 0.7,
        "topic": ["a duplicate charge", "an unexpected fee on the statement", "a billing discrepancy",
                  "being charged twice", "an incorrect late fee"],
        "subject": ["Duplicate charge on statement", "Unexpected fee on latest bill", "Billing amount does not match quote",
                    "Charged twice for the same order", "Incorrect late fee applied", "Overbilled after plan change"],
        "issue": [
            "Member was charged twice for ${amount} on {date} and wants the duplicate removed.",
            "Customer disputes an unexpected fee of ${amount} that appeared on the {date} statement.",
            "Member says the amount billed does not match the quote they received; difference of ${amount}.",
            "A late fee of ${amount} was applied even though payment was made on time on {date}.",
            "Member noticed they were overbilled ${amount} after the recent plan change and asks for a correction.",
            "Recurring charge of ${amount} posted two times this cycle; member requests an investigation.",
            "Billing for order {order} came to ${amount} more than the confirmation email stated.",
        ],
        "detail": [
            "Member provided the bank statement showing both transactions.",
            "Statement review shows two postings of the same amount one day apart.",
            "Member has been a customer for years and has never missed a payment.",
            "Member says this is the second billing problem in three months.",
            "Autopay is enabled; member did not authorize a second payment.",
        ],
        "resolution": [
            "Duplicate charge reversed; ${amount} credited back within 3-5 business days.",
            "Fee waived as a one-time courtesy and a corrected statement was issued.",
            "Billing error confirmed; adjustment of ${amount} applied to the next invoice.",
            "No error found; walked the member through each line of the statement and they accepted.",
            "Escalated to billing operations for manual review; member told to expect an answer in {days} days.",
        ],
    },
    "delivery_delay": {
        "weight": 16,
        "negative": 0.65,
        "topic": ["a late delivery", "a package that has not arrived", "a delayed shipment",
                  "tracking that has not updated", "a missing order"],
        "subject": ["Order has not arrived", "Delivery delayed beyond promised date", "Tracking shows no movement",
                    "Package marked delivered but not received", "Shipment stuck in transit"],
        "issue": [
            "Order {order} was promised by {date} and still has not arrived.",
            "Tracking for order {order} has shown no movement for {days} days.",
            "Package is marked as delivered but the member never received it.",
            "Member's {product} shipment is stuck at a regional hub and is now {days} days late.",
            "Delivery was rescheduled twice without notice; member needed the item for an event.",
            "Member waited at home for the delivery window on {date} and nobody came.",
        ],
        "detail": [
            "Carrier shows a failed delivery attempt that the member says never happened.",
            "Member checked with neighbors and the building office; nothing found.",
            "Member needs the item urgently and asked about expedited replacement.",
            "Shipping address on the order was verified as correct.",
        ],
        "resolution": [
            "Replacement shipped with overnight delivery at no charge.",
            "Carrier trace opened; member refunded ${amount} while the investigation runs.",
            "Order re-routed and delivered within {days} days; shipping fee refunded.",
            "Courtesy credit of ${amount} applied for the inconvenience.",
        ],
    },
    "product_defect": {
        "weight": 10,
        "negative": 0.6,
        "topic": ["a defective product", "a device that stopped working", "a damaged item",
                  "a product that arrived broken", "a faulty unit"],
        "subject": ["Product stopped working", "Item arrived damaged", "Defective unit received",
                    "Device fails to power on", "Product does not match description"],
        "issue": [
            "The {product} stopped working after {days} days of normal use.",
            "Member received a {product} with visible damage to the packaging and the unit.",
            "The {device} will not power on out of the box.",
            "Product from order {order} does not match the description on the website.",
            "Member reports the {product} overheats and shuts down repeatedly.",
        ],
        "detail": [
            "Member sent photos showing the damage.",
            "Troubleshooting steps were completed without success.",
            "Unit is still within the warranty period.",
            "Member has tried a different outlet and cable with the same result.",
        ],
        "resolution": [
            "Warranty replacement approved and shipped; prepaid return label emailed.",
            "Full refund of ${amount} issued after the return was received.",
            "Advance exchange arranged; member keeps the old unit until the new one arrives.",
            "Repair ticket created with the service center; estimated turnaround {days} days.",
        ],
    },
    "account_access": {
        "weight": 9,
        "negative": 0.5,
        "topic": ["a locked account", "trouble logging in", "a password reset that does not work",
                  "two-factor codes not arriving", "being unable to sign in"],
        "subject": ["Cannot log in to online account", "Account locked after failed attempts",
                    "Password reset email never arrives", "Two-factor code not received"],
        "issue": [
            "Member cannot sign in; the account was locked after several failed attempts.",
            "Password reset emails are not arriving even after checking spam folders.",
            "Two-factor authentication codes are not being delivered to the phone on file.",
            "Member changed phone numbers and can no longer pass verification.",
            "Login page shows an error after the latest app update.",
        ],
        "detail": [
            "Identity verified with date of birth and billing zip code.",
            "Member is traveling and needs access today.",
            "Email address on file was confirmed as correct.",
        ],
        "resolution": [
            "Account unlocked and a secure password reset link sent.",
            "Phone number on file updated after identity verification; codes now arrive.",
            "Cleared the security hold and walked the member through logging in.",
            "Escalated to the identity team for manual verification.",
        ],
    },
    "plan_change": {
        "weight": 8,
        "negative": 0.15,
        "topic": ["upgrading the plan", "changing membership tier", "downgrading service",
                  "adding a line", "switching billing cycle"],
        "subject": ["Plan upgrade request", "Downgrade membership tier", "Add a new line to account",
                    "Change billing cycle date"],
        "issue": [
            "Member wants to move from {plan_old} to {plan_new} starting next cycle.",
            "Customer asks to downgrade from {plan_old} to {plan_new} to reduce monthly cost.",
            "Member would like to add another line and asked how pricing works.",
            "Member requests moving the billing date to align with payday.",
        ],
        "detail": [
            "Explained proration and the effect on the next statement.",
            "Member compared options and asked about contract terms.",
            "No outstanding balance on the account.",
        ],
        "resolution": [
            "Plan changed to {plan_new}; confirmation email sent.",
            "Change scheduled for the next billing cycle; member informed of the new rate.",
            "Line added and activated during the call.",
        ],
    },
    "cancellation_request": {
        "weight": 8,
        "negative": 0.55,
        "topic": ["canceling the account", "closing the membership", "ending service",
                  "wanting to leave", "a retention offer"],
        "subject": ["Request to cancel service", "Membership cancellation", "Considering leaving over pricing",
                    "Cancel before renewal"],
        "issue": [
            "Member wants to cancel because the price increased by ${amount} per month.",
            "Customer asks to close the account before the renewal on {date}.",
            "Member is switching to a competitor offering a lower rate and asked about cancellation steps.",
            "Member is relocating and no longer needs service at the new address.",
            "Member is unhappy with repeated service problems and wants to end the contract.",
        ],
        "detail": [
            "Retention offer was presented, including a discount for {days} months.",
            "Member asked whether an early termination fee applies.",
            "Member has been with the company for several years.",
        ],
        "resolution": [
            "Member accepted the retention discount and stayed.",
            "Cancellation processed effective {date}; confirmation sent by email.",
            "Early termination fee waived due to the service problems documented on the account.",
            "Member declined all offers; account closed and final bill explained.",
        ],
    },
    "privacy_request": {
        "weight": 4,
        "negative": 0.1,
        "topic": ["a data deletion request", "a copy of personal data", "opting out of marketing",
                  "updating consent preferences", "a privacy inquiry"],
        "subject": ["Data deletion request", "Request copy of personal data", "Opt out of marketing communications",
                    "Update communication preferences"],
        "issue": [
            "Member asks for all personal data held to be deleted.",
            "Member requests a copy of the personal data on file.",
            "Customer wants to stop all marketing emails and text messages.",
            "Member asks who the data is shared with and wants to restrict sharing.",
        ],
        "detail": [
            "Request logged with the privacy team and the identity check completed.",
            "Explained the regulatory timeline for responding.",
        ],
        "resolution": [
            "Marketing preferences updated; member removed from all campaigns.",
            "Privacy team opened a request; member will receive a response within 30 days.",
            "Data export prepared and delivered through the secure portal.",
        ],
    },
    "fraud_alert": {
        "weight": 6,
        "negative": 0.8,
        "topic": ["an unrecognized transaction", "suspected fraud on the account", "unauthorized charges",
                  "a suspicious login alert", "a compromised card"],
        "subject": ["Unrecognized transaction", "Suspected account takeover", "Unauthorized charges reported",
                    "Suspicious login alert"],
        "issue": [
            "Member does not recognize a ${amount} transaction posted on {date}.",
            "Member received a login alert from a location they have never visited.",
            "Customer reports several unauthorized purchases totaling ${amount}.",
            "Member believes their credentials were stolen after a phishing email.",
        ],
        "detail": [
            "Card was blocked immediately as a precaution.",
            "Member confirmed they still have the physical card.",
            "Recent password change recommended and two-factor authentication enabled.",
        ],
        "resolution": [
            "Fraud claim opened; provisional credit of ${amount} issued and a new card ordered.",
            "Credentials reset, active sessions ended, and monitoring enabled on the account.",
            "Disputed transactions reversed after review by the fraud team.",
        ],
    },
    "refund_request": {
        "weight": 11,
        "negative": 0.45,
        "topic": ["a refund", "returning an item", "a missing refund", "a return that was never credited",
                  "a refund status"],
        "subject": ["Refund not received", "Return not credited", "Request refund for unused service",
                    "Refund status inquiry"],
        "issue": [
            "Member returned order {order} on {date} and has not received the ${amount} refund.",
            "Customer asks for a refund for a service period they did not use.",
            "Refund was promised {days} days ago and has not appeared on the card.",
            "Member returned the {product} and the system still shows it as not received.",
        ],
        "detail": [
            "Return tracking confirms the package was delivered to the warehouse.",
            "Member kept the receipt and the return confirmation number.",
            "Refund was issued to an old card that has since been replaced.",
        ],
        "resolution": [
            "Refund of ${amount} released and confirmed by email.",
            "Refund reissued to the current card on file.",
            "Warehouse located the return; refund processed in full.",
            "Partial refund of ${amount} approved after inspection.",
        ],
    },
    "service_outage": {
        "weight": 10,
        "negative": 0.75,
        "topic": ["a service outage", "intermittent connectivity", "slow service performance",
                  "no service since yesterday", "repeated disconnections"],
        "subject": ["Service down in my area", "Frequent disconnections", "Very slow performance",
                    "No service since yesterday"],
        "issue": [
            "Member reports no service since {date} and needs it restored.",
            "Service drops several times a day; member has tried restarting the {device}.",
            "Performance has been very slow for {days} days, even outside peak hours.",
            "Member works from home and lost service during important meetings.",
        ],
        "detail": [
            "Checked the area and found a known outage affecting nearby addresses.",
            "Remote diagnostics show a weak signal on the member's line.",
            "Member has already restarted all equipment twice.",
        ],
        "resolution": [
            "Technician appointment scheduled and a bill credit of ${amount} applied for the outage.",
            "Outage resolved by the network team; service confirmed restored.",
            "Replacement {device} shipped to fix the weak signal.",
            "Credit of ${amount} added for the days without service.",
        ],
    },
}

# Notes that are not tied to a case (routine contacts)
GENERIC_NOTES = {
    "positive_feedback": [
        "Member called to thank the team for resolving the earlier issue quickly and said they will recommend us.",
        "Customer praised the support agent and asked that the compliment be recorded.",
        "Member happy with the recent upgrade and the speed of the technician visit.",
    ],
    "address_update": [
        "Member moved and updated the mailing and billing address; identity verified before the change.",
        "Address on file corrected after a returned mailing; confirmation email sent.",
        "Member asked to add a secondary shipping address for deliveries at work.",
    ],
    "loyalty_inquiry": [
        "Member asked how many reward points are available and how to redeem them for a statement credit.",
        "Customer asked about benefits of the next membership tier and what spend is needed to qualify.",
        "Member asked whether points expire and how to transfer them to a family member.",
    ],
    "general_question": [
        "Member asked about store hours and the return policy; answered and shared the link.",
        "Customer asked how to download past statements; walked through the steps in the portal.",
        "Member wanted to confirm the autopay date and payment method on file; confirmed and no changes made.",
        "Member asked for help understanding the new app features; sent the quick start guide.",
    ],
}

NOTE_OPENERS = {
    "phone": ["Inbound call: member contacted us about {topic}.", "Spoke with member by phone regarding {topic}.",
              "Member called in re: {topic}."],
    "chat": ["Chat session: member raised {topic}.", "Live chat. Member asked for help with {topic}.",
             "Chat transcript summary: {topic}."],
    "email": ["Email received about {topic}.", "Member emailed support regarding {topic}.",
              "Written inquiry received on {topic}."],
    "branch": ["Walk-in visit: member came in about {topic}.", "In-person visit at branch regarding {topic}."],
}

TONE = {
    "negative": ["Member was frustrated and asked to speak with a supervisor.",
                 "Member expressed strong dissatisfaction with how long this has taken.",
                 "Member was upset and said they may take their business elsewhere.",
                 "Tone was tense but the member calmed down once a solution was offered."],
    "neutral": ["Member was calm and cooperative throughout.",
                "Standard interaction, no escalation needed.",
                "Member asked clear questions and followed the steps provided."],
    "positive": ["Member was pleasant and thanked the agent for the help.",
                 "Member was satisfied with the outcome and gave positive feedback."],
}

FOLLOWUPS = [
    "Follow-up scheduled in {days} days.",
    "No follow-up needed; resolved on first contact.",
    "Case notes updated and member informed of next steps.",
    "Member will call back if the issue persists.",
    "Callback promised within {days} business days.",
]

PRODUCTS = ["smart thermostat", "wireless router", "home security camera", "noise-cancelling headphones",
            "air purifier", "tablet", "robot vacuum", "fitness tracker", "coffee maker", "set-top box"]
DEVICES = ["router", "modem", "set-top box", "smart hub", "mobile app", "thermostat"]
PLANS = ["Basic", "Plus", "Premier", "Family", "Business Essentials", "Business Pro"]
PRODUCT_CATEGORIES = ["Home & Living", "Electronics", "Wearables", "Subscriptions", "Accessories", "Services"]
