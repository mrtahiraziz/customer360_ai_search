"""Generate synthetic Customer 360 data locally as Parquet files (build/data/*.parquet).

Tables produced:
  ref_nicknames, members_source (deliberately messy), member_orders, member_cases, member_notes

Everything is fake. Seeded for reproducibility.
Usage: uv run python data_gen/generate_data.py [--members 10000]
"""
import argparse
import random
import re
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from faker import Faker

from text_library import (CATEGORIES, DEVICES, FOLLOWUPS, GENERIC_NOTES, NICKNAMES, NOTE_OPENERS,
                          PLANS, PRODUCT_CATEGORIES, PRODUCTS, TONE)

SEED = 20261122
TODAY = date(2026, 11, 20)
OUT = Path(__file__).resolve().parent.parent / "build" / "data"

rng = random.Random(SEED)
nrng = np.random.default_rng(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

FIRST_NAMES = (
    list(NICKNAMES.keys())
    + ["Emily", "Olivia", "Sophia", "Emma", "Ava", "Mia", "Charlotte", "Amelia", "Harper", "Evelyn", "Grace", "Chloe",
       "Liam", "Noah", "Oliver", "Elijah", "Lucas", "Mason", "Ethan", "Logan", "Henry", "Owen", "Wyatt", "Caleb",
       "Priya", "Aarav", "Wei", "Mei", "Hiroshi", "Yuki", "Min-jun", "Seo-yeon", "Omar", "Fatima", "Amir", "Layla",
       "Mateo", "Sofia", "Diego", "Valentina", "Carlos", "Camila", "Luis", "Lucia", "Zoë", "Chloé", "André", "Renée",
       "Aisha", "Kofi", "Amara", "Tariq", "Ingrid", "Lars", "Sven", "Katarzyna", "Dmitri", "Svetlana"]
)
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez",
    "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez",
    "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen",
    "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green", "Adams", "Nelson", "Baker", "Hall",
    "Rivera", "Campbell", "Mitchell", "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker",
    "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales", "Murphy", "Cook", "Rogers", "Gutierrez",
    "Ortiz", "Morgan", "Cooper", "Peterson", "Bailey", "Reed", "Kelly", "Howard", "Ramos", "Kim", "Cox", "Ward",
    "Richardson", "Watson", "Brooks", "Chavez", "Wood", "James", "Bennett", "Gray", "Mendoza", "Ruiz", "Hughes",
    "Price", "Alvarez", "Castillo", "Sanders", "Patel", "Myers", "Long", "Ross", "Foster", "Jimenez", "Chen", "Wang",
    "Zhang", "Liu", "Singh", "Shah", "Khan", "Ali", "Ahmed", "Tanaka", "Sato", "Park", "Choi", "O'Brien", "McDonald",
    "Smyth", "Smythe", "Johnston", "Johnstone", "Müller", "Schmidt", "Fernández", "Peña", "Núñez", "Álvarez", "Dubois",
    "Kowalski", "Petrov", "Olsen", "Hansen", "Okafor", "Mensah", "Nakamura", "Yamamoto", "Haddad", "Nasser",
]
LAST_WEIGHTS = np.array([5.0] * 20 + [2.5] * 30 + [1.0] * (len(LAST_NAMES) - 50))
LAST_WEIGHTS = LAST_WEIGHTS / LAST_WEIGHTS.sum()

# (city, state, zip3, [area codes])
CITIES = [
    ("Dallas", "TX", "752", [214, 469, 972]), ("Houston", "TX", "770", [713, 281, 832]), ("Austin", "TX", "787", [512]),
    ("San Antonio", "TX", "782", [210]), ("Columbus", "OH", "432", [614]), ("Cleveland", "OH", "441", [216]),
    ("Cincinnati", "OH", "452", [513]), ("Chicago", "IL", "606", [312, 773]), ("Springfield", "IL", "627", [217]),
    ("New York", "NY", "100", [212, 646, 917]), ("Buffalo", "NY", "142", [716]), ("Los Angeles", "CA", "900", [213, 323]),
    ("San Jose", "CA", "951", [408]), ("San Diego", "CA", "921", [619]), ("Sacramento", "CA", "958", [916]),
    ("Seattle", "WA", "981", [206]), ("Portland", "OR", "972", [503]), ("Phoenix", "AZ", "850", [602, 480]),
    ("Denver", "CO", "802", [303, 720]), ("Atlanta", "GA", "303", [404, 678]), ("Miami", "FL", "331", [305, 786]),
    ("Orlando", "FL", "328", [407]), ("Tampa", "FL", "336", [813]), ("Charlotte", "NC", "282", [704]),
    ("Raleigh", "NC", "276", [919]), ("Boston", "MA", "021", [617]), ("Philadelphia", "PA", "191", [215]),
    ("Pittsburgh", "PA", "152", [412]), ("Detroit", "MI", "482", [313]), ("Minneapolis", "MN", "554", [612]),
    ("Nashville", "TN", "372", [615]), ("Las Vegas", "NV", "891", [702]), ("Salt Lake City", "UT", "841", [801]),
    ("Kansas City", "MO", "641", [816]), ("Indianapolis", "IN", "462", [317]), ("Baltimore", "MD", "212", [410]),
    ("Richmond", "VA", "232", [804]), ("Newark", "NJ", "071", [973]), ("Hartford", "CT", "061", [860]),
    ("New Orleans", "LA", "701", [504]),
]
CITY_WEIGHTS = np.array([4, 4, 3, 2, 3, 2, 2, 3, 1, 4, 1, 4, 2, 2, 1, 2, 1, 2, 2, 3, 3, 2, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2,
                         1, 1, 1, 1, 1, 1, 1, 1], dtype=float)
CITY_WEIGHTS = CITY_WEIGHTS / CITY_WEIGHTS.sum()

EMAIL_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "hotmail.com", "aol.com", "protonmail.com",
                 "comcast.net", "att.net"]
ACCENT_FOLD = str.maketrans("áàâäãåéèêëíìîïóòôöõúùûüñçÁÀÂÄÃÅÉÈÊËÍÌÎÏÓÒÔÖÕÚÙÛÜÑÇ", "aaaaaaeeeeiiiiooooouuuuncAAAAAAEEEEIIIIOOOOOUUUUNC")


def ascii_fold(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.translate(ACCENT_FOLD).lower())


def pick(seq, weights=None):
    if weights is None:
        return seq[rng.randrange(len(seq))]
    return seq[int(nrng.choice(len(seq), p=weights))]


def rand_date(start: date, end: date) -> date:
    return start + timedelta(days=rng.randint(0, max((end - start).days, 0)))


def rand_ts(d: date) -> datetime:
    return datetime(d.year, d.month, d.day, rng.randint(7, 20), rng.randint(0, 59), rng.randint(0, 59))


# --------------------------------------------------------------------------- members
used_emails: set[str] = set()
used_phones: set[str] = set()


def make_email(first: str, last: str) -> str:
    f, l = ascii_fold(first), ascii_fold(last)
    styles = [f"{f}.{l}", f"{f}{l}", f"{f[0]}{l}", f"{f}_{l}", f"{l}.{f}", f"{f}.{l}{rng.randint(1, 99)}",
              f"{f}{l}{rng.randint(1970, 2005)}", f"{f[0]}.{l}"]
    domain = pick(EMAIL_DOMAINS)
    for _ in range(20):
        local = pick(styles)
        if domain in ("gmail.com",) and rng.random() < 0.15:
            local = local.replace(".", "")
        addr = f"{local}@{domain}"
        if addr not in used_emails:
            used_emails.add(addr)
            return addr
    addr = f"{f}.{l}{rng.randint(100, 99999)}@{domain}"
    used_emails.add(addr)
    return addr


def make_phone(area_codes: list[int]) -> str:
    """Return 10 digits (no punctuation)."""
    for _ in range(50):
        num = f"{pick(area_codes)}{rng.randint(201, 989)}{rng.randint(0, 9999):04d}"
        if num[3:6] != "555" and num not in used_phones:
            used_phones.add(num)
            return num
    raise RuntimeError("could not generate unique phone")


def messy_phone(digits: str) -> str:
    a, b, c = digits[:3], digits[3:6], digits[6:]
    return pick([f"({a}) {b}-{c}", f"{a}-{b}-{c}", f"{a}.{b}.{c}", digits, f"+1 {a} {b} {c}", f"1-{a}-{b}-{c}",
                 f"({a}){b}-{c}"], [0.3, 0.25, 0.1, 0.1, 0.1, 0.1, 0.05])


def messy_case(s: str) -> str:
    r = rng.random()
    if r < 0.06:
        return s.upper()
    if r < 0.10:
        return s.lower()
    if r < 0.12:
        return f" {s} "
    return s


def messy_email(e: str) -> str:
    r = rng.random()
    if r < 0.10:
        return e.upper() if rng.random() < 0.4 else e.title()
    if r < 0.12:
        return f" {e}"
    return e


# hand-written members used in the live demo (clusters of similar names, accents, nicknames)
DEMO_MEMBERS = [
    ("John", "Smith", "Dallas", "platinum", date(2018, 4, 12)),
    ("Jonathan", "Smith", "Columbus", "gold", date(2025, 3, 8)),
    ("Jon", "Smyth", "Austin", "silver", date(2021, 9, 30)),
    ("Johnny", "Smythe", "Houston", "bronze", date(2023, 1, 17)),
    ("Katherine", "Johnson", "Houston", "gold", date(2019, 6, 2)),
    ("Catherine", "Johnson", "Cleveland", "gold", date(2025, 7, 21)),
    ("Kathryn", "Johnston", "Cincinnati", "silver", date(2022, 11, 5)),
    ("Robert", "Chen", "San Jose", "platinum", date(2017, 2, 14)),
    ("Elizabeth", "Taylor", "Columbus", "gold", date(2025, 5, 19)),
    ("José", "García", "San Antonio", "gold", date(2020, 8, 25)),
    ("Jose", "Garcia", "Miami", "silver", date(2024, 2, 9)),
    ("Michael", "O'Brien", "Boston", "gold", date(2025, 1, 30)),
    ("Priya", "Patel", "Atlanta", "gold", date(2025, 10, 3)),
    ("Zoë", "Müller", "Seattle", "silver", date(2023, 5, 27)),
]


def build_members(n: int) -> pd.DataFrame:
    rows = []
    tiers = ["platinum", "gold", "silver", "bronze"]
    tier_w = [0.05, 0.15, 0.30, 0.50]
    city_by_name = {c[0]: c for c in CITIES}

    def row(i, first, last, city_tuple, tier=None, join=None):
        city, state, z3, areas = city_tuple
        digits = make_phone(areas)
        email = make_email(first, last)
        join_d = join or rand_date(date(2014, 1, 1), date(2026, 10, 31))
        status = pick(["active", "inactive", "suspended"], [0.88, 0.09, 0.03])
        mid = f"M{10_000_000 + i}"
        src_ids = [f"CRM-{rng.randint(100000, 999999)}"]
        if rng.random() < 0.6:
            src_ids.append(f"BILL-{rng.randint(100000, 999999)}")
        if rng.random() < 0.25:
            src_ids.append(f"SVC-{rng.randint(100000, 999999)}")
        return {
            "member_id": mid,
            "first_name": messy_case(first),
            "last_name": messy_case(last),
            "email_raw": messy_email(email),
            "phone_raw": messy_phone(digits),
            "dob": rand_date(date(1945, 1, 1), date(2005, 12, 31)),
            "street": fake.street_address(),
            "city": city,
            "state": state,
            "zip": f"{z3}{rng.randint(0, 99):02d}",
            "tier": tier or pick(tiers, tier_w),
            "status": status,
            "segment": pick(["consumer", "small_business", "premium"], [0.70, 0.20, 0.10]),
            "join_date": join_d,
            "source_ids_raw": "|".join(src_ids),
            "updated_at": rand_ts(rand_date(max(join_d, date(2026, 1, 1)), TODAY)),
        }

    i = 0
    for first, last, city, tier, join in DEMO_MEMBERS:
        r = row(i, first, last, city_by_name[city], tier, join)
        r["first_name"], r["last_name"] = first, last  # keep demo names clean
        r["status"] = "active"
        rows.append(r)
        i += 1
    while i < n:
        first = pick(FIRST_NAMES)
        last = pick(LAST_NAMES, LAST_WEIGHTS)
        city_tuple = pick(CITIES, CITY_WEIGHTS)
        rows.append(row(i, first, last, city_tuple))
        i += 1
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- orders / cases / notes
def build_orders(members: pd.DataFrame) -> pd.DataFrame:
    rows, oid = [], 1
    for m in members.itertuples():
        k = int(nrng.poisson(3.2))
        for _ in range(k):
            od = rand_date(m.join_date, TODAY)
            rows.append({
                "order_id": f"ORD-{oid:07d}", "member_id": m.member_id, "order_date": od,
                "amount": round(float(np.clip(nrng.lognormal(4.3, 0.8), 6, 2500)), 2),
                "status": pick(["delivered", "returned", "cancelled", "in_transit"], [0.88, 0.05, 0.04, 0.03]),
                "product_category": pick(PRODUCT_CATEGORIES),
            })
            oid += 1
    return pd.DataFrame(rows)


def fill(template: str, ctx: dict) -> str:
    return template.format(**ctx)


def make_ctx(order_id: str, ref_date: date) -> dict:
    return {
        "amount": f"{rng.randint(5, 480)}.{rng.randint(0, 99):02d}",
        "date": (ref_date - timedelta(days=rng.randint(1, 20))).strftime("%b %d"),
        "order": order_id,
        "product": pick(PRODUCTS),
        "days": rng.randint(2, 14),
        "plan_old": pick(PLANS),
        "plan_new": pick(PLANS),
        "device": pick(DEVICES),
    }


def build_cases(members: pd.DataFrame, orders: pd.DataFrame) -> pd.DataFrame:
    orders_by_member = orders.groupby("member_id")["order_id"].apply(list).to_dict()
    cats = list(CATEGORIES.keys())
    w = np.array([CATEGORIES[c]["weight"] for c in cats], dtype=float)
    w = w / w.sum()
    rows, cid = [], 1
    for m in members.itertuples():
        k = int(nrng.poisson(1.25))
        for _ in range(k):
            cat = pick(cats, w)
            lib = CATEGORIES[cat]
            opened = rand_date(max(m.join_date, date(2023, 1, 1)), TODAY)
            order_id = pick(orders_by_member[m.member_id]) if orders_by_member.get(m.member_id) else "ORD-0000000"
            ctx = make_ctx(order_id, opened)
            age = (TODAY - opened).days
            is_open = rng.random() < (0.55 if age < 10 else 0.20 if age < 45 else 0.05)
            closed = None if is_open else min(opened + timedelta(days=rng.randint(1, 21)), TODAY)
            description = fill(pick(lib["issue"]), ctx) + " " + fill(pick(lib["detail"]), ctx)
            resolution = None if is_open else fill(pick(lib["resolution"]), ctx)
            rows.append({
                "case_id": f"CASE-{cid:06d}", "member_id": m.member_id, "category": cat,
                "subject": pick(lib["subject"]), "description": description, "resolution": resolution,
                "status": "open" if is_open else "closed",
                "priority": pick(["low", "medium", "high", "urgent"], [0.25, 0.5, 0.2, 0.05]),
                "channel": pick(["phone", "chat", "email", "branch"], [0.4, 0.3, 0.25, 0.05]),
                "opened_at": rand_ts(opened), "closed_at": rand_ts(closed) if closed else None,
                "related_order_id": order_id,
            })
            cid += 1
    return pd.DataFrame(rows)


def sentiment_for(cat: str | None, resolved: bool) -> str:
    if cat is None:
        return pick(["neutral", "positive"], [0.7, 0.3])
    neg = CATEGORIES[cat]["negative"]
    if resolved and rng.random() < 0.25:
        return "positive"
    return "negative" if rng.random() < neg else "neutral"


def build_notes(members: pd.DataFrame, cases: pd.DataFrame, orders: pd.DataFrame) -> pd.DataFrame:
    cases_by_member = {k: g for k, g in cases.groupby("member_id")}
    rows, nid = [], 1

    def add(member_id, created, channel, cat, text, sentiment, case_id):
        nonlocal nid
        rows.append({
            "note_id": f"NOTE-{nid:07d}", "member_id": member_id, "case_id": case_id, "channel": channel,
            "category": cat or "general", "created_at": created, "agent": f"agent_{rng.randint(1, 60):02d}",
            "sentiment": sentiment, "note_text": text,
        })
        nid += 1

    for m in members.itertuples():
        mcases = cases_by_member.get(m.member_id)
        # 1-2 notes per case (call-center follow-ups) ...
        if mcases is not None:
            for c in mcases.itertuples():
                lib = CATEGORIES[c.category]
                ctx = make_ctx(c.related_order_id, c.opened_at.date())
                for j in range(rng.randint(1, 2)):
                    channel = c.channel if j == 0 else pick(["phone", "chat", "email"])
                    topic = pick(lib["topic"])
                    resolved = c.status == "closed" and j == 1 or (c.status == "closed" and rng.random() < 0.4)
                    sentiment = sentiment_for(c.category, resolved)
                    parts = [fill(pick(NOTE_OPENERS[channel]), {"topic": topic}),
                             fill(pick(lib["issue"]), ctx), fill(pick(lib["detail"]), ctx)]
                    if resolved and c.resolution:
                        parts.append("Outcome: " + c.resolution)
                    parts.append(pick(TONE[sentiment]))
                    parts.append(fill(pick(FOLLOWUPS), ctx))
                    created = c.opened_at + timedelta(days=j * rng.randint(1, 6), hours=rng.randint(0, 5))
                    add(m.member_id, min(created, datetime(2026, 11, 20, 18, 0)), channel, c.category, " ".join(parts),
                        sentiment, c.case_id)
        # ... plus routine contacts not tied to a case
        for _ in range(int(nrng.poisson(1.6))):
            key = pick(list(GENERIC_NOTES.keys()))
            channel = pick(["phone", "chat", "email", "branch"], [0.4, 0.3, 0.25, 0.05])
            sentiment = "positive" if key == "positive_feedback" else sentiment_for(None, False)
            text = pick(GENERIC_NOTES[key]) + " " + pick(TONE[sentiment])
            created = rand_ts(rand_date(max(m.join_date, date(2023, 1, 1)), TODAY))
            add(m.member_id, created, channel, key, text, sentiment, None)
    return pd.DataFrame(rows)


def build_nicknames() -> pd.DataFrame:
    return pd.DataFrame([{"canonical_name": k, "nickname": n} for k, v in NICKNAMES.items() for n in v])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--members", type=int, default=10_000)
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)

    members = build_members(args.members)
    orders = build_orders(members)
    cases = build_cases(members, orders)
    notes = build_notes(members, cases, orders)
    nick = build_nicknames()

    for name, df in [("members_source", members), ("member_orders", orders), ("member_cases", cases),
                     ("member_notes", notes), ("ref_nicknames", nick)]:
        path = OUT / f"{name}.parquet"
        # microsecond timestamps: Spark cannot read nanosecond Parquet timestamps
        df.to_parquet(path, index=False, coerce_timestamps="us", allow_truncated_timestamps=True)
        print(f"{name:16s} {len(df):>8,d} rows -> {path}")

    print("\nSample note:\n ", notes.sample(1, random_state=1).iloc[0]["note_text"])
    print("Sample case:\n ", cases.sample(1, random_state=2).iloc[0]["description"])


if __name__ == "__main__":
    main()
