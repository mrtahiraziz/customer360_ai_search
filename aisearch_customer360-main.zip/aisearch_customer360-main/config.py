"""Shared configuration for setup scripts (data load, AI Search creation, smoke tests).

Every value can be overridden with an environment variable, so nobody needs to edit this file:

  DATABRICKS_CONFIG_PROFILE  Databricks CLI profile to use           (default: fe_azure_east)
  C360_CATALOG               existing Unity Catalog catalog           (default: fe_tahir_aziz)
  C360_SCHEMA                schema to create inside that catalog     (default: customer360_search)
  C360_WAREHOUSE_ID          existing serverless SQL warehouse ID     (default: the demo workspace's warehouse)
  C360_LLM_ENDPOINT          Foundation Model API chat endpoint       (default: databricks-claude-haiku-4-5)
  C360_SEARCH_ENDPOINT       AI Search endpoint to create/use         (default: c360-search-ep)
  C360_APP_NAME              Databricks App name                      (default: c360-member-search)

See deployment_steps.md.
"""
import os

PROFILE = os.environ.get("DATABRICKS_CONFIG_PROFILE", "fe_azure_east")

CATALOG = os.environ.get("C360_CATALOG", "fe_tahir_aziz")
SCHEMA = os.environ.get("C360_SCHEMA", "customer360_search")
FQ = f"{CATALOG}.{SCHEMA}"
VOLUME = "staging"

# Existing serverless warehouse (no new warehouse is created)
WAREHOUSE_ID = os.environ.get("C360_WAREHOUSE_ID", "148ccb90800933a1")

SEARCH_ENDPOINT = os.environ.get("C360_SEARCH_ENDPOINT", "c360-search-ep")
MEMBER_INDEX = f"{FQ}.member_search_idx"
INTERACTION_INDEX = f"{FQ}.interaction_search_idx"

EMBEDDING_ENDPOINT = "databricks-gte-large-en"
LLM_ENDPOINT = os.environ.get("C360_LLM_ENDPOINT", "databricks-claude-haiku-4-5")

APP_NAME = os.environ.get("C360_APP_NAME", "c360-member-search")
