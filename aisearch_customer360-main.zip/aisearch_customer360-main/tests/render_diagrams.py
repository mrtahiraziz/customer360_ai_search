"""Render docs/diagrams/*.mmd to SVG + PNG with Mermaid in system Chrome (Playwright).
Usage: uv run python tests/render_diagrams.py [path/to/mermaid.min.js]"""
import sys, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "docs" / "diagrams"
MJS = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/mmd/node_modules/mermaid/dist/mermaid.min.js")
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
FONT = '"IBM Plex Sans", "Helvetica Neue", Arial, sans-serif'

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
    for f in sorted(SRC.glob("*.mmd")):
        page = b.new_page(viewport={"width": 1800, "height": 1200}, device_scale_factor=2)
        page.set_content("<html><body style='margin:0;background:#fff'><div id='out' style='display:inline-block;padding:24px'></div></body></html>")
        page.add_script_tag(path=str(MJS))
        svg = page.evaluate("""async ([code, font]) => {
            mermaid.initialize({startOnLoad:false, securityLevel:'loose', theme:'base',
              flowchart:{htmlLabels:true, curve:'basis', useMaxWidth:false, nodeSpacing:40, rankSpacing:55, wrappingWidth:340},
              sequence:{useMaxWidth:false, mirrorActors:false, wrap:false},
              themeVariables:{fontFamily:font, fontSize:'15px', primaryColor:'#fff1ee', primaryBorderColor:'#ff3621',
                primaryTextColor:'#1b2328', lineColor:'#5b6770', secondaryColor:'#eef0f3', tertiaryColor:'#f7f8fa',
                actorBkg:'#0b2026', actorTextColor:'#ffffff', actorBorder:'#0b2026', signalColor:'#1b2328',
                noteBkgColor:'#fff8e1', activationBkgColor:'#dff3f1'}});
            const r = await mermaid.render('g', code);
            document.getElementById('out').innerHTML = r.svg; return r.svg; }""", [f.read_text(), FONT])
        (SRC / f"{f.stem}.svg").write_text(svg)
        page.locator("#out").screenshot(path=str(SRC / f"{f.stem}.png"))
        print("rendered", f.stem)
        page.close()
    b.close()
