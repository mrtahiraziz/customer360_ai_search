"""Hit the running API with representative queries and print what comes back. Usage: smoke.py [base_url] [query ...]"""
import json, sys, time
import httpx

BASE = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].startswith("http") else "http://127.0.0.1:8010"
QUERIES = [a for a in sys.argv[1:] if not a.startswith("http")] or [
    "Jon Smyth", "bob chen", "Jose Garcia", "j.smith@gmail", "john.smith@gmail.com", "972 718 3898", "M10000007",
    "gold members in Ohio who joined in 2025",
]

def show(q, use_ai=False):
    t = time.time()
    r = httpx.post(f"{BASE}/api/search", json={"query": q, "use_ai": use_ai}, timeout=90)
    ms = int((time.time() - t) * 1000)
    if r.status_code != 200:
        print(f"\n### {q!r}  HTTP {r.status_code}: {r.text[:300]}"); return
    d = r.json()
    p = d["parsed"]
    print(f"\n### {q!r}  [{ms} ms, server {d['latency_ms']} ms] source={p['source']} intent={p['intent']} total={d['total']}")
    print("    engines:", d["engines"], " timings:", d["timings_ms"])
    if d.get("message"): print("    message:", d["message"][:120])
    for h in d["results"][:6]:
        sn = (" | note: " + h["snippets"][0]["text"][:90]) if h["snippets"] else ""
        print(f"    {h['member_id']} {h['full_name']:<20} {h['city']},{h['state']} {h['tier']:<8} {h['matched_on']}{sn}")

for q in QUERIES:
    show(q)
