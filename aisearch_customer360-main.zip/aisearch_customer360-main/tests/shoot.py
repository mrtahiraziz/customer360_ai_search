"""Drive the local app with Chrome and save screenshots. Usage: shoot.py <name> <query?> [--ai] [--open N] [--url URL]"""
import argparse, sys, time
from playwright.sync_api import sync_playwright

ap = argparse.ArgumentParser()
ap.add_argument("name"); ap.add_argument("query", nargs="?", default="")
ap.add_argument("--ai", action="store_true"); ap.add_argument("--open", type=int, default=0)
ap.add_argument("--url", default="http://127.0.0.1:8010"); ap.add_argument("--wait", type=float, default=6)
ap.add_argument("--fold", action="store_true"); ap.add_argument("--width", type=int, default=1360); ap.add_argument("--height", type=int, default=900)
a = ap.parse_args()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", headless=True)
    pg = b.new_page(viewport={"width": a.width, "height": a.height})
    logs = []
    pg.on("console", lambda m: logs.append(f"[{m.type}] {m.text}") if m.type in ("error", "warning") else None)
    pg.on("requestfailed", lambda r: logs.append(f"[requestfailed] {r.url}"))
    pg.goto(a.url, wait_until="networkidle")
    if a.ai:
        pg.get_by_label("Always interpret my search with AI").check()
    if a.query:
        pg.get_by_label("Search members").fill(a.query)
        pg.keyboard.press("Enter")
        try:
            pg.wait_for_selector(".count-line, .error", timeout=int(a.wait * 1000) + 20000)
        except Exception:
            pass
        time.sleep(0.5)
    if a.open:
        pg.locator(".row").nth(a.open - 1).click()
        pg.wait_for_selector(".phead, .panel .error", timeout=20000)
        time.sleep(0.5)
    out = f"tests/shots/{a.name}.png"
    pg.screenshot(path=out, full_page=not (a.open or a.fold))
    print("saved", out)
    if a.query:
        print("count:", pg.locator(".count-line").inner_text() if pg.locator(".count-line").count() else "n/a")
        if pg.locator(".error").count(): print("error:", pg.locator(".error").first.inner_text())
    for l in logs[:10]: print(l)
    b.close()
