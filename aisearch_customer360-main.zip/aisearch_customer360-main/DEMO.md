# Customer 360 Member Search — v1 Demo

Full design: [docs/customer360_search_architecture.md](docs/customer360_search_architecture.md)

## Goal
Show a business user finding members by name, email, phone, ID, free-text criteria, and the content of
call notes and cases — fast, typo-tolerant, ranked — on governed lakehouse data. Replaces a regex search bar.
All data is **synthetic**.

## Locked decisions
| Topic | Decision |
|---|---|
| Search engine | Databricks AI Search (hybrid, full-text, reranker). **No Lakebase.** |
| NL understanding | LLM parser (Foundation Model API) → intent, filters, query rewrites |
| App | React (Vite) + FastAPI on Databricks Apps |
| Profile reads | Serverless SQL Warehouse (`Shared Endpoint`, existing — no new warehouse) |
| Unstructured data | Synthetic contact-center notes + cases in v1 |

## Workspace objects (all under catalog `fe_tahir_aziz`)
| Object | Name |
|---|---|
| Workspace / profile | `adb-984752964297111.11.azuredatabricks.net` / `fe_azure_east` |
| Schema | `fe_tahir_aziz.customer360_search` |
| Volume (staging) | `fe_tahir_aziz.customer360_search.staging` |
| AI Search endpoint (dedicated) | `c360-search-ep` |
| Member index | `fe_tahir_aziz.customer360_search.member_search_idx` |
| Interaction index | `fe_tahir_aziz.customer360_search.interaction_search_idx` |
| Audit table | `fe_tahir_aziz.customer360_search.search_events` |
| App | `c360-member-search` |

## Data model (Delta, Unity Catalog)
- `ref_nicknames` — nickname lookup (Bob→Robert …)
- `members_source` — messy "silver" input (mixed phone/email formats, casing, accents)
- `member_golden` — normalized: `full_name_norm`, `name_phonetic` (soundex), `name_aliases`, `phone_e164`, `phone_last4`, `email_norm`, `email_local` …
- `member_search_doc` — one `search_text` per member (index source, CDF on)
- `member_cases`, `member_notes`, `member_orders` — synthetic activity
- `member_interactions` — notes + cases as search chunks (index source, CDF on)
- `member_profile` — 360 aggregates (served via warehouse)

## Query paths in the app
1. Typeahead → AI Search `FULL_TEXT` on members, no LLM
2. Email / phone / ID → normalized filter lookups
3. Name / free text → LLM rewrite (nicknames, typos, phonetics) → `HYBRID`
4. Notes / cases → `HYBRID` + reranker on interactions → grouped by member
5. NL with criteria → LLM → JSON filters + text → `HYBRID`
6. Profile page → warehouse point reads

## Style
Neutral enterprise look: dark navy (#0B2026) + Databricks orange (#FF3621) accent, off-white surfaces.
No customer brand supplied yet.

## Deploy it in your own workspace
Follow [deployment_steps.md](deployment_steps.md) (step by step, with expected output and troubleshooting).

## Deployed app
- URL: https://c360-member-search-984752964297111.11.azure.databricksapps.com (app `c360-member-search`)
- Source: `/Workspace/Users/tahir.aziz@databricks.com/c360-member-search`
- Redeploy: `cd app && databricks sync . <source path> --exclude "frontend/**" --profile fe_azure_east && databricks apps deploy c360-member-search --source-code-path <source path> --profile fe_azure_east`
- Rebuild UI first when frontend changes: `cd app/frontend && npx vite build` (outputs to `app/static`)
- Local dev: `cd app && uv run --project .. uvicorn backend.main:app --port 8010`

## Demo script
See [DEMO_SCRIPT.md](DEMO_SCRIPT.md) for the full step-by-step script: exact inputs to type, what you should see, and what to say, for every scenario (names, identifiers, typeahead, plain-language filters, notes/case search, 360 profile, name plus topic, analytical).
