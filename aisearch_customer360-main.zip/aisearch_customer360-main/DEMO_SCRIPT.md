# Demo script — Customer 360 Member Search

**App:** https://c360-member-search-984752964297111.11.azure.databricksapps.com
**Data:** 10,000 synthetic members, ~47k notes and cases. Nothing here is real customer data.
**Run time:** about 20 minutes for the full flow, about 8 minutes for the short flow (marked **[short]**).

Everything below was run against the deployed stack. Timings are what I measured; yours will vary by a few hundred ms.

---

## 0. Before you start

- Open the app once and run any search about 2 minutes before the demo. The first request after idle is slower.
- Leave **"Always interpret my search with AI"** unchecked. The app decides on its own when to call the language model (LLM).
- Keep this framing in your head. The customer's portal today uses a regex search bar, so every scenario below is something regex can't do, or can't do well.

**The one-line story:** *one search box, five kinds of questions, the right engine picked automatically.*

| What the user types | What the app does | Typical speed |
|---|---|---|
| An ID, email or phone | Exact lookup, no LLM | 150–300 ms |
| A name (typos, nicknames) | Name matching in AI Search, no LLM | 300–600 ms |
| A sentence with filters | LLM turns it into filters, then AI Search | 1.2–1.6 s |
| A question about notes/cases | LLM + AI Search hybrid + reranker | 2–2.5 s |
| A name plus a topic | All of the above, best name match first | 2–3.5 s |

After each search, point at the **"Searching for / AI understood your request as"** strip under the search box. It shows the interpretation, the engine used and the timing. That strip is the key to the whole demo, because it makes the search explainable.

---

## Data flow at a glance (show these before or during the demo)

Three diagrams (sources and rendered images are in `docs/diagrams/`, rebuild with `uv run python tests/render_diagrams.py`).

**Diagram 1: the whole system.** Show this first (about 1 minute).

![Architecture and data flow](docs/diagrams/01_architecture_data_flow.png)

How to explain it, top to bottom:
1. The **React UI** talks to a **FastAPI** backend, both packaged in one Databricks App.
2. The backend first runs a **rules parser** (microseconds, no LLM). Only if the text is a sentence does it call the **Foundation Model API** (green box at the right), and only to get a small JSON of filters back.
3. The **router** then picks one of three data sources: the **AI Search endpoint** (names, filters and notes), the **SQL warehouse** (source-system IDs and the 360 profile), or both.
4. Everything sits on **Unity Catalog Gold tables**. The two **AI Search indexes** are *Delta Sync* copies of those tables, so they stay in step with the data automatically. No data leaves Databricks and there is no Lakebase.
5. Every search writes one audit row (dotted line) so usage is governed.

**Diagram 2: how one search box becomes 8 different flows.** This is the key diagram (about 3 minutes). Walk it from the top.

![Query routing](docs/diagrams/02_query_routing.png)

The colors tell the story: **green flows never call the LLM** (fast and cheap), **teal flows do**. Read it as three questions the app asks in order:
1. *Is the AI box ticked?* If not, try the **rules** first.
2. *Does the text look like an ID, email, phone or a plain name?* If yes, go straight to Flows 1 or 2 with no LLM.
3. *Otherwise it's a sentence.* The LLM turns it into an **intent** plus filters, and the intent chooses Flow 4, 5, 6 or 7.

**Diagram 3: one request in detail (name plus topic, then a profile click).** Use this when someone asks "what actually happens behind the scenes?" (about 2 minutes).

![Name plus topic sequence](docs/diagrams/03_name_plus_topic_sequence.png)

### Which scenario uses which flow

| Flow | What it is | Uses LLM? | Data source | Demo section | Example input |
|---|---|---|---|---|---|
| 1 | Identifier lookup (ID, email, phone) | No | AI Search filter; SQL warehouse for source IDs | 2 | `john.smith@gmail`, `3898`, `CRM-154185` |
| 2 | Name search (typos, nicknames) | No | AI Search HYBRID, member index | 1 | `Jon Smyth`, `bob chen` |
| 3 | Typeahead | No | AI Search FULL_TEXT, member index | 3 | type `jon sm` |
| 4 | Plain-language filters | Yes | AI Search filters (HYBRID if a name is included) | 4 | `gold members in Ohio who joined in 2025` |
| 5 | Notes and cases, semantic | Yes | AI Search HYBRID + reranker (interaction index), then member index | 5 | `customers who were charged twice and are still waiting for a refund` |
| 6 | Name plus topic | Yes | Member index, then interaction index (reranked) | 7 | `Jon Smyth privacy request` |
| 7 | Analytical question | Yes (to detect it) | None (notice only) | 9 | `how many platinum members churned last quarter` |
| 8 | 360 profile | No | SQL warehouse, 4 parallel reads | 6 | click **Robert Chen** |
| 4 + 5 | Filters and notes combined | Yes | Same as Flow 5, with filters applied to the notes search | 8 | `platinum members in Texas with an open case about delivery delays in the last 90 days` |

**A useful way to say it:** "The cheaper and more certain the question, the fewer moving parts it uses. An ID never touches the LLM. A sentence gets one LLM call, and the LLM can only choose from allowed filter values."

---

## 1. Names: typos, nicknames and spelling variants  **[short]**

**Flow 2** (name search). No LLM: rules parser → AI Search HYBRID on the member index → re-rank by name match → badges.

**Why it matters:** this is the biggest pain with regex. A regex can't know that Bob is Robert or that Smyth sounds like Smith.

| # | Type this | What you should see | What to say |
|---|---|---|---|
| 1.1 | `Jon Smyth` | **Jon Smyth** first (Exact name), then John Smyth, Johnny Smythe, John Smith ×2, John Schmidt, with badges *Nickname (Jon ↔ John)* and *Sounds like*. About 7 results. | "One misspelled name finds every plausible person. Each result says why it matched." |
| 1.2 | `bob chen` | Exactly the two **Robert Chen** members, badge *Nickname (Bob ↔ Robert)*. | "Nobody has 'Bob' on file, but the nickname table finds Robert." |
| 1.3 | `Katherine Johnson` | Katherine Johnson (Exact name), then two **Kathryn Johnson** (*Sounds like*). | "Spelling variants of the same name, ranked below the exact match." |
| 1.4 | `Robbert Chen` | The two Robert Chens (*Sounds like*). | "A typo regex would miss entirely." |
| 1.5 | `Jose Garcia` | Four "Jose Garcia" plus **José García** (accents). | "Accented and plain spellings are treated as the same person." |
| 1.5b | `Smtih` or `Jhon Smith` | Smiths ranked by sound (*Sounds like*). `Jhon Smith` returns the John Smith members. | "Transposed letters are caught by phonetic matching." |
| 1.6 | `chen, robert` | The two Robert Chens (Exact name). Takes about 1.4 s because "last, first" order goes through the LLM. | "Different name formats also work." |

**Click-through:** click a result to open the 360 profile drawer. Show contact details, lifetime value, open cases and contact history. See section 6.

---

## 2. Exact identifiers: fast and precise  **[short]**

**Flow 1** (identifier lookup). No LLM: rules parser → AI Search *filter* on the exact field (member ID, email, phone). Source IDs go through the SQL warehouse first. Partial emails use FULL_TEXT.

**Why it matters:** when someone pastes an ID or phone number, the app must be exact and fast. No LLM is involved and none is needed.

| # | Type this | What you should see | What to say |
|---|---|---|---|
| 2.1 | `M10000007` | One member, **Robert Chen**, badge *Member ID*. About 200 ms. | "Member ID, exact." |
| 2.2 | `CRM-154185` | **Robert Chen**, badge *Source ID CRM-154185*. About 650 ms. | "Source-system IDs, through a SQL warehouse lookup." |
| 2.3 | `john.smith@gmail.com` | **John Smith** (Dallas), badge *Email exact*. | "Exact email." |
| 2.4 | `john.smith@gmail` | Same member, badge *Email contains*. | "Partial emails work too, which regex users often can't do." |
| 2.5 | `(972) 718-3898` | John Smith, badge *Phone exact*. | "Phone number in any format." |
| 2.6 | `972 718 3898` or `+19727183898` | Same result. | "Spaces, dashes or +1: normalized to the same number." |
| 2.7 | `3898` | John Smith, badge *Phone ends/contains 3898*. | "Last-4-digits lookup, which agents use all the time." |

---

## 3. Typeahead while typing  **[short]**

**Flow 3** (typeahead). A separate request on every pause in typing: rules only → AI Search FULL_TEXT → last word completed from a name vocabulary. Never calls the LLM.

**Why it matters:** the dropdown appears in about 200–300 ms. It never calls the LLM.

| # | Slowly type | What you should see |
|---|---|---|
| 3.1 | `jon sm` | Jon Smyth, Johnny Smythe, John Smyth, John Smith. |
| 3.2 | `chen` | A list of Chens (Mei, Valentina, Oliver, Amir…). |
| 3.3 | `rob` | Roberts, with badge *Nickname (Rob ↔ Robert)*. |

Say: "AI Search matches whole words, not prefixes, so the app completes the last word from a name vocabulary. That's a design trade-off I'd tell the customer about."

Press Enter after typing to run the full search. The dropdown should close and stay closed.

---

## 4. Plain-language filters  **[short]**

**Flow 4**. Rules don't recognise a sentence → LLM parser returns filters → AI Search filter-only query on the member index. Point at the teal strip: it shows exactly what the LLM understood.

**Why it matters:** business users can describe the group they want instead of using five dropdowns. The LLM only produces *filters* (limited to allowed values like tier, state, status). It never invents results.

| # | Type this | What you should see | Notes |
|---|---|---|---|
| 4.1 | `gold members in Ohio who joined in 2025` | 13 members, all gold, OH, joined 2025. Teal strip lists the parsed filters. About 1.5 s. | The headline example. |
| 4.2 | `inactive silver members in Florida` | 24 silver, inactive, FL. | Three filters in one sentence. |
| 4.3 | `small business customers in Chicago` | 25 small-business members in Chicago. | A customer segment, not just a tier. |
| 4.4 | `gold or platinum members in New York with suspended status` | 9 members, gold or platinum, NY, suspended. | "Or" handled across two values. |
| 4.5 | `smith dallas gold` | A few Smiths in Dallas with gold tier (e.g. Olivia, Jessica, Katherine Smith). | Keyword-style, no sentence. Name plus city plus tier. |
| 4.6 | `Members who joined in the last 6 months in California` | California members, join date limited to the last 6 months. | Relative dates are resolved by the LLM. |

**Then show the facets:** with 4.1 on screen, click a **State** or **Tier** box in the left panel. The results narrow without retyping. Try `smith`, then Tier **Platinum** and State **TX**: 3 results (Harper Smith, Seo-yeon Smith, John Smith).

---

## 5. Search inside notes and cases (the semantic part)  **[short]**

**Flow 5**. LLM parser extracts the topic and any filters → AI Search HYBRID + reranker on the *interaction* index (47k chunks) → results grouped by member → member cards fetched from the member index. Engines shown in the strip: `AI Search (hybrid + reranker)` and `AI Search (filter)`.

**Why it matters:** this is what a regex can never do. The words in the query don't have to appear in the note. The index understands meaning.

| # | Type this | What you should see | Notes |
|---|---|---|---|
| 5.1 | `customers who were charged twice and are still waiting for a refund` | 25 members, each with a **billing dispute case, status open**, with the matching text shown as a quote. About 2–2.5 s. | "Still waiting" is understood as *open*. The strip shows `Case open`. |
| 5.2 | `angry customers who threatened to cancel` | Members with cancellation-request notes (email, phone, chat). | No note contains "angry", but the meaning matches. |
| 5.3 | `members who reported suspected fraud on their account` | Notes and cases about fraud alerts and suspected account takeover. | |
| 5.4 | `customers with a privacy or data deletion request` | Cases titled "Data deletion request". | A compliance-style question. |
| 5.5 | `members who asked about loyalty points expiring` | Notes where members asked whether points expire. | A positive-intent search, not only complaints. |
| 5.6 | `customers who contacted us by phone about a password or login problem` | Account-access cases. | The channel (phone) is understood as a filter. |
| 5.7 | `members with negative feedback about product quality in the last 6 months` | Product-defect notes. | Sentiment plus time window. |

Say: "Results show the member and the exact note that matched, so an agent can judge relevance without opening anything."

---

## 6. The 360 profile drawer  **[short]**

**Flow 8**. A different request, triggered by the click rather than Enter: four parallel reads on the SQL warehouse. No search engine and no LLM involved.

1. Search `bob chen`, then click the **Robert Chen** in San Jose (platinum, M10000007).
2. Walk through the drawer:
   - **Health banner** at the top (open issues, if any).
   - Contact details, address, member-since, date of birth, **source system IDs** (CRM-154185, SVC-534826).
   - Four numbers: lifetime value, orders in 12 months, open cases, last contact.
   - **Contact history** tab: includes a refund request case and chat summary.
   - **Orders** tab: three orders.
3. Say: "This is a live read from the Gold table through a SQL warehouse. Search finds the member, and the warehouse serves the full record. It loads in about a second."

---

## 7. A name plus a topic (combined)

**Flow 6**. Show Diagram 3 here. LLM parser → name search on the member index (Flow 2) → notes search restricted to those candidates → name-match order first, matching note as the snippet.

**Why it matters:** the way agents actually talk: "what's going on with this person and X?"

Each demo member was seeded with a specific topic, so these always hit:

| # | Type this | What you should see |
|---|---|---|
| 7.1 | `Jon Smyth privacy request` | **Jon Smyth** first, with the *Data deletion request* case. John Smyth (also a privacy case) follows. |
| 7.2 | `Jonathan Smith billing disputes` | **Jonathan Smith (Columbus, M10000001)** first, with the billing-dispute case ("Overbilled after plan change"). |
| 7.3 | `Katherine Johnson product defect` | **Katherine Johnson** first, with the *Item arrived damaged* case. |
| 7.4 | `Jose Garcia fraud alert` | **Jose Garcia (Miami)** first, with the *Suspicious login alert* case. |
| 7.5 | `Johnny Smythe delivery delays` | **Johnny Smythe** first, with the *Shipment stuck in transit* case. |
| 7.6 | `Robert Chen refund` | The two Robert Chens, the San Jose one with the *Request refund for unused service* case. |

Say: "Name matching decides *who*, and the notes search decides *what they said*. Both run in one request."

**Honest note:** for the second and third people in these lists, the quoted note is simply their best-matching note and may not be on the topic. The first result is the one to point at.

---

## 8. Everything combined

**Flows 4 + 5 together.** One LLM call extracts the tier, state, case status, time window and topic; the notes search runs with those filters.

| # | Type this | What you should see |
|---|---|---|
| 8.1 | `platinum members in Texas with an open case about delivery delays in the last 90 days` | 2–3 Texas platinum members (e.g. Lawrence Thompson in Dallas, Ava Martinez in Houston), each with an **open** delivery-delay case. Strip shows tier, state, case status, time window and topic. |
| 8.2 | `angry customers who threatened to cancel`, then tick State **TX** | Same search, narrowed to Texas members. |

Say: "That sentence has a tier, a state, a case status, a time window and a topic. Five conditions, one box, about two seconds."

---

## 9. What the app deliberately does *not* do (set expectations)

**Flow 7**. The LLM recognises an analytical intent and the app stops: no search runs, only a notice.

| # | Type this | What you should see |
|---|---|---|
| 9.1 | `how many platinum members churned last quarter` | A notice instead of results: "This looks like an analytical question… In production it would be routed to a Genie space; that path is not part of this v1 demo." |

Say: "Counting and trends are analytics, not search. The design routes those to Genie. It's not built in v1 so the demo stays focused."

---

## 10. Closing points to make

1. **Right engine for each question.** Exact lookups never touch the LLM. The LLM is only used when the text is a sentence, and it can only produce filters from a fixed list of allowed values.
2. **Explainable.** Every result shows why it matched, and the strip shows what the app understood.
3. **Governed.** Every search is written to a `search_events` table with user, intent, engines and latency. Run this to show it:

   ```sql
   SELECT user_email, query_text, intent, engines, latency_ms, event_ts
   FROM fe_tahir_aziz.customer360_search.search_events
   ORDER BY event_ts DESC LIMIT 20;
   ```
4. **No Lakebase needed,** as the customer required. The trade-off (AI Search matches words, not characters) is handled with phonetic codes, a nickname table and prefix completion from a vocabulary.
5. **Next steps for the customer:** run their 20–50 real queries (including the ones regex fails on) through this app and compare. That is the Phase 4 bake-off in the architecture doc.

---

## Short flow (8 minutes)

Diagram 1 (1 min) → 1.1 `Jon Smyth` → 1.2 `bob chen` → open the profile (section 6) → 2.4 `john.smith@gmail` → 2.7 `3898` → 3.1 typeahead `jon sm` → 4.1 `gold members in Ohio who joined in 2025` → facet click → 5.1 `customers who were charged twice and are still waiting for a refund` → 9.1 analytical notice → Diagram 2 (2 min) to tie the flows together.

## If something looks off

| Symptom | Likely cause | What to do |
|---|---|---|
| First search takes 5–10 s | App or endpoint was idle | Wait; repeat the search. It will be fast after that. |
| A sentence returns name-like results | Text was read as a name | Tick **Always interpret my search with AI**, then rerun. |
| Notes search returns nothing | Index still syncing | Both indexes were fully synced when this script was written (10,000 and 47,466 rows). Check endpoint `c360-search-ep` in the workspace. |
| Dropdown stays open over results | Old cached page | Refresh the browser tab. |

## Limits to be upfront about

- Data is synthetic. Notes come from templates, so many look similar. Real notes will be messier and the semantic search should do relatively better there.
- AI Search matches words, not characters. Typos that keep the same sound are caught (`Smtih`, `Smitth`, `Jhon Smith` all work), but a typo in the first letter (for example `Zmith`) gives loose results with no match badge. A character-level engine would do better there. Don't demo that one unless the customer asks about the trade-off.
- The "AI understood" interpretation is only as good as the LLM. It is limited to allowed filter values, but it can occasionally read a request differently than you meant. The strip lets the user see and correct that.
