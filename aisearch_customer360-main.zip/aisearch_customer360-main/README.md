# Customer 360 Member Search on Databricks

A working demo of a **Customer 360 search front end** built as a **Databricks App**. Business users type one thing in one box (a name, an ID, an email, a phone number, or a plain-language question) and the app picks the right search method behind the scenes.

It uses **Databricks AI Search** (Vector Search), a **Foundation Model API** LLM that turns sentences into filters, a **serverless SQL warehouse**, and **Unity Catalog** data. A **FastAPI** backend and a **React** UI run together as one app. There is **no Lakebase** and no data leaves Databricks.

> All data is **synthetic** (10,000 members, about 47,000 notes and cases). No real customer data is included.

## What it can do

| Type this | What happens |
|---|---|
| `Jon Smyth` or `bob chen` | Finds Jon Smyth, John Smith, Johnny Smythe, or both Robert Chens. Handles typos, nicknames and spelling variants, and shows why each result matched |
| `M10000007`, an email, `(972) 718-3898`, `3898` | Exact lookups on IDs, full or partial email, and phone numbers in any format |
| `jon sm` (while typing) | Typeahead suggestions in about 200 to 300 ms |
| `gold members in Ohio who joined in 2025` | The LLM turns the sentence into filters, shown back to the user |
| `customers who were charged twice and are still waiting for a refund` | Semantic search inside notes and cases, with the matching note quoted |
| `Jon Smyth privacy request` | Finds the person first, then what their notes say about the topic |
| Click a member | 360 profile: contact details, orders, cases and contact history |

Every search is written to an audit table.

## How it works

![Architecture and data flow](docs/diagrams/01_architecture_data_flow.png)

Simple inputs (IDs, emails, phones, plain names) never touch the LLM. Only sentences do, and the LLM can only choose from a fixed list of allowed filter values.

![Query routing](docs/diagrams/02_query_routing.png)

## Get started

| I want to... | Go to |
|---|---|
| **Deploy this in my own workspace** | [`deployment_steps.md`](deployment_steps.md) (about 1 to 1.5 hours, mostly waiting) |
| **Run a demo** and know what to type | [`DEMO_SCRIPT.md`](DEMO_SCRIPT.md) |
| Understand the design and the options considered | [`docs/customer360_search_architecture.md`](docs/customer360_search_architecture.md) |
| See the data flow in detail | [`docs/diagrams/`](docs/diagrams/) |

### What you need
- A Databricks workspace with Unity Catalog, a serverless SQL warehouse, AI Search (Vector Search), Foundation Model APIs and Databricks Apps
- The Databricks CLI, [uv](https://docs.astral.sh/uv/) and git (Node.js only if you change the UI)

### The short version
```bash
git clone https://github.com/tahir-aziz_data/aisearch_customer360.git
cd aisearch_customer360
uv sync

# choose your settings (full list in deployment_steps.md)
export DATABRICKS_CONFIG_PROFILE=<your-cli-profile>
export C360_PROFILE=$DATABRICKS_CONFIG_PROFILE
export C360_CATALOG=<an-existing-catalog>
export C360_WAREHOUSE_ID=<serverless-warehouse-id>

uv run python setup/01_load_and_build_gold.py   # schema, tables, Gold layer
uv run python setup/00_create_endpoint.py       # AI Search endpoint (15 to 20 min)
uv run python setup/02_create_indexes.py        # two indexes (10 to 40 min)
```

Then create and deploy the app (steps 9 to 13 in [`deployment_steps.md`](deployment_steps.md)).

## Repository layout

| Path | What is in it |
|---|---|
| `app/backend/` | FastAPI: query parser (rules + LLM), search router, name matching, profile, audit |
| `app/frontend/`, `app/static/` | React source, and the built UI that the app serves |
| `app/app.yaml` | How Databricks Apps runs the backend |
| `setup/` | Scripts that create the tables, the AI Search endpoint and indexes, and the app permissions |
| `build/data/` | The synthetic source data (Parquet) |
| `data_gen/` | The generator that produced the data (optional) |
| `tests/` | Smoke test and screenshot and diagram helpers |
| `docs/` | Architecture reference and diagrams |

## Known limits
- AI Search matches whole words, not characters. Typos that sound the same (`Smtih`, `Jhon Smith`) are handled with phonetic codes, a nickname table and prefix completion. A typo in the first letter (`Zmith`) gives loose results.
- Analytical questions such as "how many members churned last quarter" show a notice instead of results. In a full design they would go to Genie.
- The LLM's reading of a sentence can vary slightly between runs. The app always shows how it understood the request.

## Cost note
The AI Search endpoint is billed while it exists. When you finish, follow the clean-up section at the end of [`deployment_steps.md`](deployment_steps.md).
