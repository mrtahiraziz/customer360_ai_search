"""Turns the raw search box text into a ParsedQuery.

Fast path (no LLM, microseconds): email, phone, member/source ID and plain names.
LLM path (Foundation Model API): free text with criteria ("gold members in Ohio who joined in 2025 and
complained about billing"). Output is validated and clamped to known values so the model can never inject
an arbitrary filter column or value.
"""
from __future__ import annotations

import re
from datetime import date

from . import clients, settings
from .models import ParsedQuery

TIERS = ["bronze", "silver", "gold", "platinum"]
STATUSES = ["active", "inactive", "suspended"]
SEGMENTS = ["consumer", "small_business", "premium"]
SENTIMENTS = ["negative", "neutral", "positive"]
CHANNELS = ["phone", "chat", "email", "branch"]
CATEGORIES = ["billing_dispute", "delivery_delay", "product_defect", "account_access", "plan_change",
              "cancellation_request", "privacy_request", "fraud_alert", "refund_request", "service_outage"]
STATE_CODES = set("""AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND
OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY DC""".split())

EMAIL_RE = re.compile(r"[\w.+'-]*@[\w.-]*", re.I)
ID_RE = re.compile(r"^(M\d{8}|(CRM|BILL|SVC)-\d{4,})$", re.I)
# words that signal criteria / natural language -> send to the LLM parser
CRITERIA_WORDS = {
    "gold", "silver", "bronze", "platinum", "active", "inactive", "suspended", "members", "member", "customers",
    "customer", "who", "with", "that", "joined", "since", "after", "before", "in", "from", "last", "open", "closed",
    "complained", "complaint", "complaints", "billing", "refund", "refunds", "delay", "delayed", "cancel",
    "cancellation", "fraud", "outage", "unhappy", "angry", "frustrated", "case", "cases", "notes", "note",
    "called", "asked", "about", "wants", "want", "show", "find", "list", "all", "and", "or", "the", "of", "days",
    "months", "year", "week", "recent", "recently", "business", "premium", "consumer", "segment",
    # everyday issue vocabulary: these phrases describe notes/cases, not people
    "charged", "twice", "duplicate", "late", "broken", "damaged", "defective", "missing", "wrong", "package",
    "delivery", "shipping", "shipment", "order", "payment", "fee", "fees", "price", "internet", "service", "wifi",
    "login", "password", "locked", "account", "card", "stolen", "problem", "problems", "issue", "issues", "trouble",
    "slow", "down", "waiting", "still", "not", "never", "no", "has", "have", "had", "was", "were", "is", "are",
    "upset", "complain", "unauthorized", "overcharged", "returned", "return",
}

SYSTEM_PROMPT = """You convert a business user's search request about customers ("members") into one JSON object.
Today's date is {today}. Return ONLY JSON, no prose, with exactly these keys (null or [] when absent):

intent: "member_lookup" (find a specific person by name/email/phone/id), "interaction_search" (find members from what appears in their notes/cases), "filtered_nl" (criteria like tier/state/dates, optionally combined with notes), or "analytical" (asks for counts, totals, trends, comparisons)
name_query: the person's name text with obvious typos corrected, else null
name_alternatives: up to 4 alternate spellings, nicknames or formal forms of the first name or surname
semantic_query: the topic to look for inside notes/cases, as a short descriptive phrase, else null
email, phone (digits only), member_id
states: 2-letter US state codes (convert state names)
cities: proper-case city names
tiers: subset of {tiers}
statuses: subset of {statuses}
segments: subset of {segments}
join_after, join_before: YYYY-MM-DD ("joined in 2025" -> 2025-01-01 and 2025-12-31)
categories: subset of {categories}
sentiment: subset of {sentiments}
channels: subset of {channels}
case_status: "open" or "closed" or null
interaction_since, interaction_until: YYYY-MM-DD ("last 90 days" -> today minus 90 days)
explanation: one short sentence saying how you understood the request.

Rules:
- Only set categories, sentiment, channels or case_status when the user explicitly asks for them; otherwise rely on semantic_query.
- Phrases like "still waiting", "unresolved", "pending", "not resolved yet" mean case_status "open"; "resolved" or "closed" mean "closed".
- Never invent filters the user did not ask for. Do not put filter words (tiers, states, years) inside name_query or semantic_query.
- If the text is only a person's name (possibly misspelled), use intent member_lookup and fill name_query and name_alternatives.
- Keep name_query exactly as the user typed the name (do not silently correct spelling); put corrected spellings and nicknames in name_alternatives.
- If the text has a person's name AND a topic (billing, refund, delivery, fraud, privacy, defect...), use intent interaction_search, fill name_query with the name and ALWAYS fill semantic_query with the topic.

Examples:
User: gold members in Ohio who joined in 2025
{{"intent":"filtered_nl","name_query":null,"name_alternatives":[],"semantic_query":null,"email":null,"phone":null,"member_id":null,"states":["OH"],"cities":[],"tiers":["gold"],"statuses":[],"segments":[],"join_after":"2025-01-01","join_before":"2025-12-31","categories":[],"sentiment":[],"channels":[],"case_status":null,"interaction_since":null,"interaction_until":null,"explanation":"Gold-tier members in Ohio who joined during 2025."}}
User: customers who were charged twice and are still waiting for a refund
{{"intent":"interaction_search","name_query":null,"name_alternatives":[],"semantic_query":"charged twice duplicate charge waiting for refund","email":null,"phone":null,"member_id":null,"states":[],"cities":[],"tiers":[],"statuses":[],"segments":[],"join_after":null,"join_before":null,"categories":[],"sentiment":[],"channels":[],"case_status":"open","interaction_since":null,"interaction_until":null,"explanation":"Members with open cases about duplicate charges and a pending refund."}}
User: Jon Smyth privacy request
{{"intent":"interaction_search","name_query":"Jon Smyth","name_alternatives":["John Smyth","Jon Smith","Johnny Smythe"],"semantic_query":"privacy request data deletion","email":null,"phone":null,"member_id":null,"states":[],"cities":[],"tiers":[],"statuses":[],"segments":[],"join_after":null,"join_before":null,"categories":[],"sentiment":[],"channels":[],"case_status":null,"interaction_since":null,"interaction_until":null,"explanation":"Notes and cases about a privacy request for Jon Smyth."}}
User: bob chen san jose
{{"intent":"member_lookup","name_query":"Robert Chen","name_alternatives":["Bob Chen","Rob Chen","Bobby Chen"],"semantic_query":null,"email":null,"phone":null,"member_id":null,"states":["CA"],"cities":["San Jose"],"tiers":[],"statuses":[],"segments":[],"join_after":null,"join_before":null,"categories":[],"sentiment":[],"channels":[],"case_status":null,"interaction_since":null,"interaction_until":null,"explanation":"Looking for Robert (Bob) Chen in San Jose."}}
"""


def rules_parse(q: str) -> ParsedQuery | None:
    """Return a ParsedQuery for simple inputs, or None when the LLM is needed."""
    text = q.strip()
    if not text:
        return ParsedQuery(explanation="Empty query")
    if ID_RE.match(text):
        return ParsedQuery(member_id=text.upper(), explanation=f"Looking up ID {text.upper()}", source="rules")
    if "@" in text and " " not in text and EMAIL_RE.fullmatch(text):
        return ParsedQuery(email=text.lower(), explanation=f"Matching email {text.lower()}", source="rules")
    digits = re.sub(r"\D", "", text)
    if digits and re.fullmatch(r"[\d\s().+\-]+", text) and len(digits) >= 4:
        return ParsedQuery(phone=digits[-10:] if len(digits) > 10 else digits,
                           explanation=f"Matching phone digits {digits}", source="rules")
    if _is_name_like(text):
        name = " ".join(text.split())
        return ParsedQuery(name_query=name,
                           explanation=f"Matching the name “{name}” with nicknames and phonetic variants",
                           source="rules")
    return None


_NAME_RE = re.compile(r"^[^\W\d_]+(?:['’-][^\W\d_]+)*(?: [^\W\d_]+(?:['’-][^\W\d_]+)*){0,2}$", re.UNICODE)


def _is_name_like(text: str) -> bool:
    """1-3 alphabetic words, none of which look like search criteria (tiers, 'members', a state code...)."""
    clean = " ".join(text.split())
    if not _NAME_RE.match(clean):
        return False
    tokens = clean.split(" ")
    if {t.lower() for t in tokens} & CRITERIA_WORDS:
        return False
    # "smith tx" style: a trailing 2-letter state code means the user is adding criteria
    return not (len(tokens) > 1 and tokens[-1].upper() in STATE_CODES and len(tokens[-1]) == 2)


def _clamp(values, allowed: list[str]) -> list[str]:
    out = []
    for v in values or []:
        s = str(v).strip().lower()
        if s in allowed and s not in out:
            out.append(s)
    return out


def _iso(v) -> str | None:
    try:
        return date.fromisoformat(str(v)[:10]).isoformat() if v else None
    except ValueError:
        return None


def llm_parse(q: str) -> ParsedQuery:
    system = SYSTEM_PROMPT.format(today=settings.DEMO_TODAY, tiers=TIERS, statuses=STATUSES, segments=SEGMENTS,
                                  categories=CATEGORIES, sentiments=SENTIMENTS, channels=CHANNELS)
    raw = clients.llm_json(system, q)
    intent = raw.get("intent") if raw.get("intent") in ("member_lookup", "interaction_search", "filtered_nl", "analytical") else "filtered_nl"
    digits = re.sub(r"\D", "", str(raw.get("phone") or ""))
    email = (raw.get("email") or "").strip().lower() or None
    mid = (raw.get("member_id") or "").strip().upper() or None
    p = ParsedQuery(
        intent=intent,
        name_query=(raw.get("name_query") or None),
        name_alternatives=[str(a) for a in (raw.get("name_alternatives") or [])][:4],
        semantic_query=(raw.get("semantic_query") or None),
        email=email if email and "@" in email else None,
        phone=digits or None,
        member_id=mid if mid and ID_RE.match(mid) else None,
        states=[s.upper() for s in (raw.get("states") or []) if str(s).upper() in STATE_CODES],
        cities=[str(c).strip().title() for c in (raw.get("cities") or []) if str(c).strip()][:3],
        tiers=_clamp(raw.get("tiers"), TIERS),
        statuses=_clamp(raw.get("statuses"), STATUSES),
        segments=_clamp(raw.get("segments"), SEGMENTS),
        join_after=_iso(raw.get("join_after")),
        join_before=_iso(raw.get("join_before")),
        categories=_clamp(raw.get("categories"), CATEGORIES),
        sentiment=_clamp(raw.get("sentiment"), SENTIMENTS),
        channels=_clamp(raw.get("channels"), CHANNELS),
        case_status=raw.get("case_status") if raw.get("case_status") in ("open", "closed") else None,
        interaction_since=_iso(raw.get("interaction_since")),
        interaction_until=_iso(raw.get("interaction_until")),
        explanation=str(raw.get("explanation") or "")[:240],
        source="llm",
    )
    if p.name_query and not p.semantic_query and p.categories:
        # a name plus a topic category: still search the notes, using the category as the topic
        p.semantic_query = " ".join(c.replace("_", " ") for c in p.categories)
        p.intent = "interaction_search"
    return p


def parse(q: str, use_ai: bool = False) -> ParsedQuery:
    if not use_ai:
        fast = rules_parse(q)
        if fast is not None:
            return fast
    try:
        return llm_parse(q)
    except Exception as e:  # LLM unavailable -> degrade to plain keyword search rather than failing
        print(f"[parser] LLM parse failed, falling back to name search: {e}")
        return ParsedQuery(name_query=q, explanation="AI parser unavailable; using keyword search", source="rules")
