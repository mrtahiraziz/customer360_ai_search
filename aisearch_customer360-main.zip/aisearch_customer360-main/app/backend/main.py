"""FastAPI entrypoint: JSON API under /api, React build served from ./static."""
import json
import uuid
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import clients, profile, search, settings
from .models import SearchRequest, SearchResponse

app = FastAPI(title="Customer 360 Member Search", version="1.0")
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"


def _user(request: Request) -> str:
    # Databricks Apps forwards the signed-in user's identity in these headers
    return request.headers.get("x-forwarded-email") or request.headers.get("x-forwarded-preferred-username") or "local-dev"


@app.get("/api/health")
def health():
    return {"status": "ok", "llm": settings.LLM_ENDPOINT, "member_index": settings.MEMBER_INDEX,
            "interaction_index": settings.INTERACTION_INDEX, "in_app": settings.RUNNING_IN_APP}


@app.get("/api/me")
def me(request: Request):
    return {"user": _user(request)}


@app.post("/api/search", response_model=SearchResponse)
def api_search(req: SearchRequest, request: Request, background: BackgroundTasks):
    if not req.query.strip():
        raise HTTPException(400, "query is required")
    try:
        res = search.run_search(req)
    except Exception as e:  # surface a readable error to the UI instead of a bare 500
        raise HTTPException(502, f"Search failed: {e}") from e
    background.add_task(clients.write_audit, {
        "event_id": str(uuid.uuid4()), "user_email": _user(request), "query_text": req.query,
        "intent": res.parsed.intent, "parsed_json": res.parsed.model_dump_json(),
        "engines": ", ".join(res.engines), "result_count": res.total, "latency_ms": res.latency_ms,
    })
    return res


@app.get("/api/typeahead", response_model=SearchResponse)
def api_typeahead(q: str = Query(..., min_length=2, max_length=80)):
    try:
        return search.typeahead(q)
    except Exception as e:
        raise HTTPException(502, f"Typeahead failed: {e}") from e


@app.get("/api/members/{member_id}")
def api_member(member_id: str, request: Request, background: BackgroundTasks):
    data = profile.get_profile(member_id)
    if not data:
        raise HTTPException(404, "member not found")
    background.add_task(clients.write_audit, {
        "event_id": str(uuid.uuid4()), "user_email": _user(request), "query_text": f"profile:{member_id}",
        "intent": "profile_view", "parsed_json": json.dumps({"member_id": member_id}), "engines": "SQL warehouse",
        "result_count": 1, "latency_ms": 0,
    })
    return data


if STATIC_DIR.exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")

    @app.get("/{path:path}")
    def spa(path: str):
        f = STATIC_DIR / path
        if path and f.is_file():
            return FileResponse(f)
        return FileResponse(STATIC_DIR / "index.html")
