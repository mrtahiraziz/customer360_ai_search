"""Query router: turns a ParsedQuery into AI Search / warehouse calls, merges and explains the results."""
from __future__ import annotations

import json
import re
import time
from datetime import date
from pathlib import Path

from . import clients, parser, settings
from .models import MemberHit, ParsedQuery, SearchRequest, SearchResponse, Snippet
from .phonetic import ascii_fold, soundex

ALIASES: dict[str, list[str]] = json.loads((Path(__file__).parent / "aliases.json").read_text())
# name token -> member count; lets typeahead complete the word being typed (AI Search has no prefix matching)
VOCAB: dict[str, int] = json.loads((Path(__file__).parent / "vocab.json").read_text())

MEMBER_COLS = ["member_id", "full_name", "email", "phone", "phone_e164", "phone_last4", "city", "state", "tier",
               "status", "segment"]
INTERACTION_COLS = ["interaction_id", "member_id", "source_type", "title", "chunk_text", "category", "sentiment",
                    "created_at"]
EPOCH = date(1970, 1, 1)


class Timer:
    def __init__(self):
        self.t: dict[str, int] = {}

    def run(self, name: str, fn, *a, **kw):
        t0 = time.perf_counter()
        try:
            return fn(*a, **kw)
        finally:
            self.t[name] = self.t.get(name, 0) + int((time.perf_counter() - t0) * 1000)


# --------------------------------------------------------------------------- query construction
def fold(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", ascii_fold(s).lower())


def name_tokens(*texts: str | None) -> list[str]:
    out: list[str] = []
    for t in texts:
        for tok in fold(t or "").split():
            if tok not in out:
                out.append(tok)
    return out


def complete_prefix(tok: str, limit: int = 5) -> list[str]:
    """Most common vocabulary names that start with a partially typed token."""
    if len(tok) < 2:
        return []
    hits = [w for w in VOCAB if w.startswith(tok) and w != tok]
    return sorted(hits, key=lambda w: -VOCAB[w])[:limit]


def build_name_query(parsed: ParsedQuery, complete_last: bool = False) -> str:
    """Original tokens + nickname aliases + phonetic codes (matches the Gold search_text) + LLM alternatives.

    With complete_last=True (typeahead) the last word is treated as possibly unfinished and expanded
    to the names it could become, e.g. "smi" -> smith, smithe.
    """
    base = name_tokens(parsed.name_query)
    extra: list[str] = []
    for tok in base:
        extra += ALIASES.get(tok, [])
    if complete_last:
        for i, tok in enumerate(base):
            if tok not in VOCAB or i == len(base) - 1:  # unfinished words, plus the word still being typed
                extra += complete_prefix(tok)
    extra += name_tokens(*parsed.name_alternatives)
    phon = [soundex(t) for t in base if len(t) > 1 and (t in VOCAB or not complete_last)]
    seen, tokens = set(), []
    for t in base + extra + phon:
        if t and t not in seen:
            seen.add(t)
            tokens.append(t)
    return " ".join(tokens[:16])


def name_match(hit_name: str, query_tokens: list[str], typing: bool = False) -> tuple[int, list[str], int]:
    """Score how a hit's name matches the query tokens: (quality 0-3 per token summed, badges, tokens covered).

    typing=True (typeahead) also credits words that are the start of a name ("john" -> Johnson).
    """
    parts = fold(hit_name).split()
    if not parts:
        return 0, [], 0
    first, last = parts[0], parts[-1]
    score, badges, exact, nick, phon, covered = 0, [], 0, None, 0, 0
    for tok in query_tokens:
        if tok in (first, last) or tok in parts:
            score += 3
            exact += 1
            covered += 1
        elif tok in ALIASES.get(first, []) or first in ALIASES.get(tok, []):
            score += 2
            covered += 1
            nick = f"{tok.title()} ↔ {first.title()}"
        elif len(tok) >= 2 and (first.startswith(tok) or last.startswith(tok)) and (typing or tok not in VOCAB):
            score += 2  # still typing: "smi" is on its way to "smith"
            covered += 1
        elif soundex(tok) and soundex(tok) in (soundex(first), soundex(last)):
            score += 1
            phon += 1
            covered += 1
    if query_tokens and exact == len(query_tokens):
        badges.append("Exact name")
    if nick:
        badges.append(f"Nickname ({nick})")
    if phon:
        badges.append("Sounds like")
    return score, badges, covered


# --------------------------------------------------------------------------- filters
def _day(iso: str | None) -> int | None:
    return (date.fromisoformat(iso) - EPOCH).days if iso else None


def _merge(parsed_vals: list[str], ui_vals: list[str]) -> list[str]:
    if parsed_vals and ui_vals:
        both = [v for v in parsed_vals if v in ui_vals]
        return both or ["__none__"]
    return parsed_vals or ui_vals


def member_filters(p: ParsedQuery, req: SearchRequest) -> dict:
    f: dict = {}
    tiers, states, statuses = _merge(p.tiers, req.tiers), _merge(p.states, req.states), _merge(p.statuses, req.statuses)
    if tiers: f["tier"] = tiers
    if states: f["state"] = states
    if statuses: f["status"] = statuses
    if p.segments: f["segment"] = p.segments
    if p.cities: f["city"] = p.cities
    if p.join_after: f["join_day >="] = _day(p.join_after)
    if p.join_before: f["join_day <="] = _day(p.join_before)
    return f


def interaction_filters(p: ParsedQuery, req: SearchRequest) -> dict:
    f: dict = {}
    tiers, states = _merge(p.tiers, req.tiers), _merge(p.states, req.states)
    if tiers: f["tier"] = tiers
    if states: f["state"] = states
    if p.sentiment: f["sentiment"] = p.sentiment
    if p.categories: f["category"] = p.categories
    if p.channels: f["channel"] = p.channels
    if p.case_status: f["case_status"] = p.case_status
    if p.interaction_since: f["created_day >="] = _day(p.interaction_since)
    if p.interaction_until: f["created_day <="] = _day(p.interaction_until)
    return f


def _hit(row: dict) -> MemberHit:
    return MemberHit(
        member_id=row["member_id"], full_name=row.get("full_name") or "", email=row.get("email"),
        phone=row.get("phone"), city=row.get("city"), state=row.get("state"), tier=row.get("tier"),
        status=row.get("status"), segment=row.get("segment"), score=float(row.get("score") or 0),
    )


def _snippet(row: dict) -> Snippet:
    text = (row.get("chunk_text") or "")
    return Snippet(interaction_id=row["interaction_id"], source_type=row.get("source_type") or "note",
                   title=row.get("title") or "", text=text[:320] + ("…" if len(text) > 320 else ""),
                   category=row.get("category"), sentiment=row.get("sentiment"),
                   created_at=(row.get("created_at") or "")[:10] or None, score=float(row.get("score") or 0))


# --------------------------------------------------------------------------- retrieval paths
def lookup_direct(p: ParsedQuery, flt: dict, tm: Timer, engines: list[str]) -> list[MemberHit]:
    """Exact / partial identifier lookups: member id, source id, email, phone."""
    hits: list[MemberHit] = []
    if p.member_id:
        if p.member_id.startswith("M"):
            engines.append("AI Search (filter)")
            rows = tm.run("member_filter", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                          filters={**flt, "member_id": p.member_id}, num_results=5)
            hits = [_hit(r) for r in rows]
            for h in hits: h.matched_on = ["Member ID"]
        else:
            engines.append("SQL warehouse (exact)")
            ids = tm.run("source_id", clients.run_sql,
                         f"SELECT member_id FROM {settings.FQ}.member_golden WHERE array_contains(source_ids, :sid)",
                         {"sid": p.member_id})
            if ids:
                engines.append("AI Search (filter)")
                rows = tm.run("member_filter", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                              filters={**flt, "member_id": [r["member_id"] for r in ids]}, num_results=10)
                hits = [_hit(r) for r in rows]
                for h in hits: h.matched_on = [f"Source ID {p.member_id}"]
    elif p.email:
        if "@" in p.email and "." in p.email.split("@")[-1]:
            engines.append("AI Search (filter)")
            rows = tm.run("member_filter", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                          filters={**flt, "email": p.email}, num_results=10)
            hits = [_hit(r) for r in rows]
            for h in hits: h.matched_on = ["Email exact"]
        if not hits:  # partial or slightly wrong, e.g. "john.smith@gmail" or "jon.smyth@gmail.com"
            frag = p.email.lower()
            local, _, domain = frag.partition("@")
            local_alnum = re.sub(r"[^a-z0-9]", "", local)
            toks = " ".join(dict.fromkeys(
                [local_alnum] + [t for t in re.split(r"[^a-z0-9]+", frag) if t] + [soundex(t) for t in re.split(r"[^a-z]+", local) if len(t) > 2]))
            engines.append("AI Search (full-text)")
            rows = tm.run("member_search", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                          query_text=toks, query_type="FULL_TEXT", filters=flt or None, num_results=40)
            cand = [_hit(r) for r in rows]

            def contains(h: MemberHit) -> bool:
                e = (h.email or "").lower()
                return frag in e or (local_alnum and local_alnum in re.sub(r"[^a-z0-9]", "", e.split("@")[0])
                                     and domain.split(".")[0] in e.split("@")[-1])

            hits = [h for h in cand if contains(h)]
            for h in hits: h.matched_on = ["Email contains"]
            if not hits:
                hits = cand[:5]
                for h in hits: h.matched_on = ["Similar email"]
    elif p.phone:
        digits = p.phone
        engines.append("AI Search (filter)")
        key, val = ("phone_e164", f"+1{digits[-10:]}") if len(digits) >= 10 else ("phone_last4", digits[-4:])
        rows = tm.run("member_filter", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                      filters={**flt, key: val}, num_results=50)
        cand = [_hit(r) for r in rows]
        hits = [h for h in cand if digits in re.sub(r"\D", "", h.phone or "")]
        for h in hits:
            h.matched_on = ["Phone exact" if len(digits) >= 10 else f"Phone ends/contains {digits}"]
    return hits


def search_members_text(p: ParsedQuery, flt: dict, tm: Timer, engines: list[str], limit: int,
                        query_type: str = "HYBRID", complete_last: bool = False) -> list[MemberHit]:
    qtext = build_name_query(p, complete_last)
    qtoks = name_tokens(p.name_query)
    if qtext:
        engines.append(f"AI Search ({query_type.lower().replace('_', '-')})")
    else:
        engines.append("AI Search (filter)")
    rows = tm.run("member_search", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                  query_text=qtext or None, query_type=query_type if qtext else None,
                  filters=flt or None, num_results=max(limit, 40) if qtext else limit)
    hits = [_hit(r) for r in rows]
    if qtoks:
        ranked = []
        for i, h in enumerate(hits):
            q, badges, covered = name_match(h.full_name, qtoks, typing=complete_last)
            h.matched_on = badges
            h.name_rank = q
            ranked.append((-q, i, covered, h))
        ranked.sort(key=lambda x: (x[0], x[1]))
        if not complete_last and ranked:
            # keep only members whose name covers every word typed ("Jon Smyth" must not return "John Lopez"),
            # as long as at least two such members exist; otherwise show the partial matches too
            strong = [h for _, _, c, h in ranked if c == len(qtoks)]
            if len(strong) >= 2:
                return strong[:limit]
        hits = [h for _, _, _, h in ranked]
    return hits[:limit]


def search_interactions(p: ParsedQuery, req: SearchRequest, tm: Timer, engines: list[str],
                        restrict_ids: list[str] | None = None) -> tuple[list[str], dict[str, list[Snippet]]]:
    flt = interaction_filters(p, req)
    if restrict_ids:
        flt["member_id"] = restrict_ids
    engines.append("AI Search (hybrid + reranker)")
    rows = tm.run("interaction_search", clients.search_index, settings.INTERACTION_INDEX, INTERACTION_COLS,
                  query_text=p.semantic_query, query_type="HYBRID", filters=flt or None, num_results=50,
                  rerank_columns=["chunk_text"])
    order: list[str] = []
    snippets: dict[str, list[Snippet]] = {}
    for r in rows:
        mid = r["member_id"]
        if mid not in snippets:
            order.append(mid)
            snippets[mid] = []
        if len(snippets[mid]) < 2:
            snippets[mid].append(_snippet(r))
    return order, snippets


def fetch_members(ids: list[str], flt: dict, tm: Timer, engines: list[str]) -> dict[str, MemberHit]:
    if not ids:
        return {}
    engines.append("AI Search (filter)")
    rows = tm.run("member_fetch", clients.search_index, settings.MEMBER_INDEX, MEMBER_COLS,
                  filters={**flt, "member_id": ids}, num_results=max(len(ids), 10))
    return {r["member_id"]: _hit(r) for r in rows}


# --------------------------------------------------------------------------- orchestration
def run_search(req: SearchRequest, limit: int = settings.MEMBER_RESULT_LIMIT) -> SearchResponse:
    t0 = time.perf_counter()
    tm = Timer()
    parsed = tm.run("parse", parser.parse, req.query, req.use_ai)
    engines: list[str] = []
    message = None
    flt = member_filters(parsed, req)
    results: list[MemberHit] = []

    if parsed.intent == "analytical":
        message = ("This looks like an analytical question (counts, trends, comparisons). "
                   "In production it would be routed to a Genie space; that path is not part of this v1 demo.")
    elif parsed.member_id or parsed.email or parsed.phone:
        results = lookup_direct(parsed, flt, tm, engines)
    elif parsed.semantic_query:
        if parsed.name_query:
            name_hits = search_members_text(parsed, flt, tm, engines, limit)
            ids = [h.member_id for h in name_hits]
            order, snips = search_interactions(parsed, req, tm, engines, restrict_ids=ids) if ids else ([], {})
            by_id = {h.member_id: h for h in name_hits}
            rank = {mid: n for n, mid in enumerate(order)}
            # best name match first; within the same name quality, members whose notes match the topic come first
            ordered = sorted(name_hits, key=lambda h: (-h.name_rank, rank.get(h.member_id, len(rank))))
            for h in ordered:
                h.snippets = snips.get(h.member_id, [])
                h.matched_on = h.matched_on + (["Notes/cases match"] if h.snippets else [])
            results = ordered[:limit]
        else:
            order, snips = search_interactions(parsed, req, tm, engines)
            member_only = {k: v for k, v in flt.items() if k in ("city", "status", "segment", "join_day >=", "join_day <=")}
            members = fetch_members(order[: limit * 2], member_only, tm, engines)
            for mid in order:
                h = members.get(mid)
                if not h:
                    continue
                h.snippets = snips[mid]
                top = h.snippets[0]
                h.matched_on = ["Notes/cases match" + (f" · {top.category.replace('_', ' ')}" if top.category else "")]
                h.score = top.score or 0
                results.append(h)
            results = results[:limit]
    else:
        results = search_members_text(parsed, flt, tm, engines, limit)
        if not results and not parsed.source == "llm" and parsed.name_query and not req.use_ai:
            # nothing found with keywords: ask the LLM for corrected spellings and retry once
            retry = tm.run("llm_retry", parser.llm_parse, req.query)
            if retry.name_query or retry.name_alternatives:
                parsed = retry
                results = search_members_text(parsed, member_filters(parsed, req), tm, engines, limit)

    latency = int((time.perf_counter() - t0) * 1000)
    return SearchResponse(query=req.query, parsed=parsed, engines=list(dict.fromkeys(engines)), results=results,
                          total=len(results), latency_ms=latency, timings_ms=tm.t, message=message)


def typeahead(q: str, limit: int = 8) -> SearchResponse:
    """Low-latency suggestions: rules only (never the LLM), AI Search only."""
    t0 = time.perf_counter()
    tm = Timer()
    parsed = parser.rules_parse(q) or ParsedQuery(name_query=q, source="rules")
    engines: list[str] = []
    req = SearchRequest(query=q)
    if parsed.member_id or parsed.email or parsed.phone:
        results = lookup_direct(parsed, {}, tm, engines)[:limit]
    else:
        # full-text only: no query embedding, so it is the fastest path; the last word is completed from the vocabulary
        results = search_members_text(parsed, {}, tm, engines, limit, query_type="FULL_TEXT", complete_last=True)
    return SearchResponse(query=q, parsed=parsed, engines=list(dict.fromkeys(engines)), results=results,
                          total=len(results), latency_ms=int((time.perf_counter() - t0) * 1000), timings_ms=tm.t)
