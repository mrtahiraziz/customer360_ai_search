"""American Soundex, used to add phonetic tokens to queries.

The Gold pipeline stores Spark SQL soundex() codes in `member_search_doc.search_text`.
Adding the same codes for the user's query tokens lets BM25 match "Smyth" to "Smith" (S530).
"""
import re
import unicodedata

_CODES = {**dict.fromkeys("BFPV", "1"), **dict.fromkeys("CGJKQSXZ", "2"), **dict.fromkeys("DT", "3"),
          "L": "4", **dict.fromkeys("MN", "5"), "R": "6"}


def ascii_fold(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")


def soundex(word: str) -> str:
    letters = re.sub(r"[^A-Za-z]", "", ascii_fold(word)).upper()
    if not letters:
        return ""
    out = letters[0]
    last = _CODES.get(letters[0], "")
    for ch in letters[1:]:
        code = _CODES.get(ch, "")
        if code and code != last:
            out += code
        if ch not in "HW":  # H and W do not separate letters with the same code; vowels do
            last = code
    return (out + "000")[:4]
