from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Intent = Literal["member_lookup", "interaction_search", "filtered_nl", "analytical"]


class ParsedQuery(BaseModel):
    """Structured interpretation of what the user typed (from rules or from the LLM parser)."""
    intent: Intent = "member_lookup"
    name_query: str | None = None
    name_alternatives: list[str] = Field(default_factory=list)
    semantic_query: str | None = None
    email: str | None = None
    phone: str | None = None  # digits only
    member_id: str | None = None
    states: list[str] = Field(default_factory=list)
    cities: list[str] = Field(default_factory=list)
    tiers: list[str] = Field(default_factory=list)
    statuses: list[str] = Field(default_factory=list)
    segments: list[str] = Field(default_factory=list)
    join_after: str | None = None
    join_before: str | None = None
    categories: list[str] = Field(default_factory=list)
    sentiment: list[str] = Field(default_factory=list)
    channels: list[str] = Field(default_factory=list)
    case_status: str | None = None
    interaction_since: str | None = None
    interaction_until: str | None = None
    explanation: str = ""
    source: Literal["rules", "llm"] = "rules"


class SearchRequest(BaseModel):
    query: str
    use_ai: bool = False  # force the LLM parser even for simple-looking queries
    tiers: list[str] = Field(default_factory=list)  # UI facet filters
    states: list[str] = Field(default_factory=list)
    statuses: list[str] = Field(default_factory=list)


class Snippet(BaseModel):
    interaction_id: str
    source_type: str
    title: str
    text: str
    category: str | None = None
    sentiment: str | None = None
    created_at: str | None = None
    score: float | None = None


class MemberHit(BaseModel):
    member_id: str
    full_name: str
    email: str | None = None
    phone: str | None = None
    city: str | None = None
    state: str | None = None
    tier: str | None = None
    status: str | None = None
    segment: str | None = None
    score: float = 0.0
    name_rank: int = 0
    matched_on: list[str] = Field(default_factory=list)
    snippets: list[Snippet] = Field(default_factory=list)


class SearchResponse(BaseModel):
    query: str
    parsed: ParsedQuery
    engines: list[str]
    results: list[MemberHit]
    total: int
    latency_ms: int
    timings_ms: dict[str, int] = Field(default_factory=dict)
    message: str | None = None
