"""Thin wrappers around the Databricks SDK: AI Search queries, SQL warehouse reads, LLM calls."""
from __future__ import annotations

import json
import re
import threading
from functools import lru_cache
from typing import Any

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
from databricks.sdk.service.sql import StatementParameterListItem, StatementState
from databricks.sdk.service.vectorsearch import RerankerConfig, RerankerConfigRerankerParameters

from . import settings


@lru_cache(maxsize=1)
def workspace() -> WorkspaceClient:
    if settings.RUNNING_IN_APP:
        return WorkspaceClient()
    return WorkspaceClient(profile=settings.LOCAL_PROFILE)


# --------------------------------------------------------------------------- AI Search
def search_index(
    index: str,
    columns: list[str],
    *,
    query_text: str | None = None,
    query_type: str | None = None,
    filters: dict | None = None,
    num_results: int = 25,
    rerank_columns: list[str] | None = None,
) -> list[dict]:
    """Query an AI Search index and return rows as dicts (with a `score` key when the index returns one)."""
    w = workspace()
    kwargs: dict[str, Any] = dict(index_name=index, columns=columns, num_results=num_results)
    if query_text:
        kwargs["query_text"] = query_text
    if query_type:
        kwargs["query_type"] = query_type
    if filters:
        kwargs["filters_json"] = json.dumps(filters)
    if rerank_columns:
        kwargs["reranker"] = RerankerConfig(
            model="databricks_reranker",
            parameters=RerankerConfigRerankerParameters(columns_to_rerank=rerank_columns),
        )
    resp = w.vector_search_indexes.query_index(**kwargs)
    names = [c.name for c in (resp.manifest.columns or [])] if resp.manifest else columns
    rows = (resp.result.data_array or []) if resp.result else []
    out = []
    for r in rows:
        d = dict(zip(names, r))
        if "score" not in d and len(r) > len(names):
            d["score"] = r[-1]
        out.append(d)
    return out


# --------------------------------------------------------------------------- SQL warehouse
_NUMERIC = {"INT", "LONG", "SHORT", "BYTE", "BIGINT", "SMALLINT", "TINYINT"}
_FLOAT = {"DOUBLE", "FLOAT", "DECIMAL"}


def _convert(value: Any, type_name: str) -> Any:
    if value is None:
        return None
    t = (type_name or "").upper()
    try:
        if t in _NUMERIC:
            return int(value)
        if t in _FLOAT:
            return float(value)
        if t == "BOOLEAN":
            return str(value).lower() == "true"
        if t == "ARRAY":
            return json.loads(value) if isinstance(value, str) else value
    except (ValueError, TypeError):
        return value
    return value


def run_sql(statement: str, params: dict[str, Any] | None = None) -> list[dict]:
    w = workspace()
    plist = [StatementParameterListItem(name=k, value=None if v is None else str(v)) for k, v in (params or {}).items()]
    resp = w.statement_execution.execute_statement(
        warehouse_id=settings.WAREHOUSE_ID, statement=statement, parameters=plist or None, wait_timeout="30s"
    )
    if resp.status.state != StatementState.SUCCEEDED:
        err = resp.status.error
        raise RuntimeError(f"SQL failed ({resp.status.state}): {err.message if err else ''}")
    cols = resp.manifest.schema.columns if resp.manifest and resp.manifest.schema else []
    rows = resp.result.data_array if resp.result and resp.result.data_array else []
    return [{c.name: _convert(v, c.type_name.value if c.type_name else "") for c, v in zip(cols, row)} for row in rows]


# --------------------------------------------------------------------------- LLM
def llm_json(system: str, user: str, max_tokens: int = 700) -> dict:
    """Call the Foundation Model endpoint and parse the first JSON object in the reply."""
    w = workspace()
    resp = w.serving_endpoints.query(
        name=settings.LLM_ENDPOINT,
        messages=[ChatMessage(role=ChatMessageRole.SYSTEM, content=system),
                  ChatMessage(role=ChatMessageRole.USER, content=user)],
        max_tokens=max_tokens,
        temperature=0.0,
    )
    text = resp.choices[0].message.content if resp.choices else ""
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError(f"LLM returned no JSON: {text[:200]}")
    return json.loads(m.group(0))


# --------------------------------------------------------------------------- audit (background, best effort)
_audit_lock = threading.Lock()


def write_audit(event: dict) -> None:
    try:
        with _audit_lock:
            run_sql(
                f"""INSERT INTO {settings.FQ}.search_events
                    (event_id, event_ts, user_email, query_text, intent, parsed_json, engines, result_count, latency_ms)
                    VALUES (:event_id, current_timestamp(), :user_email, :query_text, :intent, :parsed_json,
                            :engines, CAST(:result_count AS INT), CAST(:latency_ms AS INT))""",
                event,
            )
    except Exception as e:  # never break a search because the audit write failed
        print(f"[audit] failed: {e}")
