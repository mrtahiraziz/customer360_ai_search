"""360 profile: point reads on Gold tables through the serverless SQL warehouse (run in parallel)."""
from concurrent.futures import ThreadPoolExecutor

from . import clients, settings

FQ = settings.FQ

Q_MEMBER = f"""
SELECT g.member_id, g.full_name, g.email, g.phone_display AS phone, g.dob, g.street, g.city, g.state, g.zip,
       g.tier, g.status, g.segment, g.join_date, g.source_ids, g.name_aliases,
       p.order_count, p.lifetime_value, p.orders_12m, p.last_order_date, p.total_cases, p.open_cases,
       p.latest_case_category, p.note_count, p.last_contact_at, p.negative_contacts_90d, p.health
FROM {FQ}.member_golden g JOIN {FQ}.member_profile p USING (member_id)
WHERE g.member_id = :id
"""
Q_CASES = f"""
SELECT case_id, category, subject, description, resolution, status, priority, channel, opened_at, closed_at
FROM {FQ}.member_cases WHERE member_id = :id ORDER BY opened_at DESC LIMIT 15
"""
Q_NOTES = f"""
SELECT note_id, case_id, channel, category, created_at, agent, sentiment, note_text
FROM {FQ}.member_notes WHERE member_id = :id ORDER BY created_at DESC LIMIT 25
"""
Q_ORDERS = f"""
SELECT order_id, order_date, amount, status, product_category
FROM {FQ}.member_orders WHERE member_id = :id ORDER BY order_date DESC LIMIT 12
"""


def get_profile(member_id: str) -> dict | None:
    p = {"id": member_id}
    with ThreadPoolExecutor(max_workers=4) as pool:
        f_m = pool.submit(clients.run_sql, Q_MEMBER, p)
        f_c = pool.submit(clients.run_sql, Q_CASES, p)
        f_n = pool.submit(clients.run_sql, Q_NOTES, p)
        f_o = pool.submit(clients.run_sql, Q_ORDERS, p)
        member = f_m.result()
        if not member:
            return None
        return {"member": member[0], "cases": f_c.result(), "notes": f_n.result(), "orders": f_o.result()}
