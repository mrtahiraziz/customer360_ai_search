"""Runtime settings. Defaults match the demo workspace; every value can be overridden by env var."""
import os

CATALOG = os.environ.get("C360_CATALOG", "fe_tahir_aziz")
SCHEMA = os.environ.get("C360_SCHEMA", "customer360_search")
FQ = f"{CATALOG}.{SCHEMA}"

MEMBER_INDEX = os.environ.get("C360_MEMBER_INDEX", f"{FQ}.member_search_idx")
INTERACTION_INDEX = os.environ.get("C360_INTERACTION_INDEX", f"{FQ}.interaction_search_idx")

WAREHOUSE_ID = os.environ.get("C360_WAREHOUSE_ID", "148ccb90800933a1")
LLM_ENDPOINT = os.environ.get("C360_LLM_ENDPOINT", "databricks-claude-haiku-4-5")

# Locally we use a CLI profile; inside Databricks Apps the SDK reads the injected service-principal env vars.
LOCAL_PROFILE = os.environ.get("C360_PROFILE", "fe_azure_east")
RUNNING_IN_APP = bool(os.environ.get("DATABRICKS_CLIENT_ID"))

# "Today" for demo-relative phrases such as "last 90 days" (synthetic data ends 2026-11-20)
DEMO_TODAY = os.environ.get("C360_TODAY", "2026-11-22")

MEMBER_RESULT_LIMIT = 25
