import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Production build goes to ../static, which FastAPI serves. In dev, /api is proxied to the local backend.
export default defineConfig({
  plugins: [react()],
  build: { outDir: "../static", emptyOutDir: true },
  server: { port: 5173, proxy: { "/api": "http://localhost:8000" } },
});
