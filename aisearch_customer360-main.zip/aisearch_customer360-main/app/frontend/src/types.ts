export type Parsed = {
  intent: "member_lookup" | "interaction_search" | "filtered_nl" | "analytical";
  name_query: string | null;
  name_alternatives: string[];
  semantic_query: string | null;
  email: string | null;
  phone: string | null;
  member_id: string | null;
  states: string[];
  cities: string[];
  tiers: string[];
  statuses: string[];
  segments: string[];
  join_after: string | null;
  join_before: string | null;
  categories: string[];
  sentiment: string[];
  channels: string[];
  case_status: string | null;
  interaction_since: string | null;
  interaction_until: string | null;
  explanation: string;
  source: "rules" | "llm";
};

export type Snippet = {
  interaction_id: string;
  source_type: string;
  title: string;
  text: string;
  category: string | null;
  sentiment: string | null;
  created_at: string | null;
  score: number | null;
};

export type MemberHit = {
  member_id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  city: string | null;
  state: string | null;
  tier: string | null;
  status: string | null;
  segment: string | null;
  score: number;
  matched_on: string[];
  snippets: Snippet[];
};

export type SearchResponse = {
  query: string;
  parsed: Parsed;
  engines: string[];
  results: MemberHit[];
  total: number;
  latency_ms: number;
  timings_ms: Record<string, number>;
  message: string | null;
};

export type Facets = { tiers: string[]; statuses: string[]; states: string[] };

export type Profile = {
  member: {
    member_id: string;
    full_name: string;
    email: string;
    phone: string;
    dob: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    tier: string;
    status: string;
    segment: string;
    join_date: string;
    source_ids: string[];
    name_aliases: string;
    order_count: number;
    lifetime_value: number;
    orders_12m: number;
    last_order_date: string | null;
    total_cases: number;
    open_cases: number;
    latest_case_category: string | null;
    note_count: number;
    last_contact_at: string | null;
    negative_contacts_90d: number;
    health: "healthy" | "watch" | "at_risk";
  };
  cases: {
    case_id: string; category: string; subject: string; description: string; resolution: string | null;
    status: string; priority: string; channel: string; opened_at: string; closed_at: string | null;
  }[];
  notes: {
    note_id: string; case_id: string | null; channel: string; category: string; created_at: string;
    agent: string; sentiment: string; note_text: string;
  }[];
  orders: { order_id: string; order_date: string; amount: number; status: string; product_category: string }[];
};
