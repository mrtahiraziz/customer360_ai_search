import { useEffect, useRef, useState } from "react";
import { Search, X, Sparkles } from "lucide-react";
import { typeahead } from "../api";
import type { MemberHit } from "../types";
import { initials } from "../format";

type Props = {
  value: string;
  onChange: (v: string) => void;
  onSubmit: (v: string) => void;
  onOpenMember: (id: string) => void;
  useAi: boolean;
  onToggleAi: (v: boolean) => void;
  busy: boolean;
};

export function SearchBox({ value, onChange, onSubmit, onOpenMember, useAi, onToggleAi, busy }: Props) {
  const [suggestions, setSuggestions] = useState<MemberHit[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const wrapRef = useRef<HTMLDivElement>(null);
  const skipNext = useRef(false);
  const submitted = useRef("");

  // Debounced typeahead: rules + AI Search only, never the LLM.
  useEffect(() => {
    if (skipNext.current) {
      skipNext.current = false;
      return;
    }
    const q = value.trim();
    if (q.length < 3 || useAi || q === submitted.current) {
      setSuggestions([]);
      return;
    }
    const ctrl = new AbortController();
    const t = setTimeout(() => {
      typeahead(q, ctrl.signal)
        .then((r) => {
          if (ctrl.signal.aborted || submitted.current === q) return;
          setSuggestions(r.results.slice(0, 6));
          setOpen(true);
          setActive(-1);
        })
        .catch(() => setSuggestions([]));
    }, 220);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [value, useAi]);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const submit = () => {
    setOpen(false);
    setSuggestions([]);
    const q = value.trim();
    if (!q) return;
    submitted.current = q; // stops a late typeahead response from reopening the list
    onSubmit(q);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown" && suggestions.length) {
      e.preventDefault();
      setOpen(true);
      setActive((a) => (a + 1) % suggestions.length);
    } else if (e.key === "ArrowUp" && suggestions.length) {
      e.preventDefault();
      setActive((a) => (a <= 0 ? suggestions.length - 1 : a - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (open && active >= 0 && suggestions[active]) {
        setOpen(false);
        onOpenMember(suggestions[active].member_id);
      } else submit();
    } else if (e.key === "Escape") setOpen(false);
  };

  return (
    <div className="searchbox" ref={wrapRef}>
      <div className="searchfield">
        <Search size={22} aria-hidden className="searchicon" />
        <input
          type="text"
          role="combobox"
          aria-expanded={open && suggestions.length > 0}
          aria-controls="suggestions"
          aria-label="Search members"
          placeholder="Search by name, email, phone, member ID, or describe who you are looking for"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setOpen(true);
          }}
          onFocus={() => suggestions.length && setOpen(true)}
          onKeyDown={onKey}
          autoFocus
          spellCheck={false}
        />
        {value && (
          <button className="iconbtn" aria-label="Clear search" onClick={() => { onChange(""); setSuggestions([]); }}>
            <X size={18} />
          </button>
        )}
        <button className="primary" onClick={submit} disabled={!value.trim() || busy}>
          {busy ? "Searching" : "Search"}
        </button>
      </div>

      {open && suggestions.length > 0 && (
        <ul id="suggestions" className="suggestions" role="listbox">
          {suggestions.map((s, i) => (
            <li
              key={s.member_id}
              role="option"
              aria-selected={i === active}
              className={i === active ? "active" : ""}
              onMouseEnter={() => setActive(i)}
              onMouseDown={(e) => {
                e.preventDefault();
                skipNext.current = true;
                setOpen(false);
                onOpenMember(s.member_id);
              }}
            >
              <span className={`avatar sm tier-${s.tier}`}>{initials(s.full_name)}</span>
              <span className="sname">{s.full_name}</span>
              <span className="smeta">
                {s.city}, {s.state}
              </span>
              <span className="mono smeta">{s.member_id}</span>
              {s.matched_on[0] && <span className="badge">{s.matched_on[0]}</span>}
            </li>
          ))}
        </ul>
      )}

      <label className="aitoggle">
        <input type="checkbox" checked={useAi} onChange={(e) => onToggleAi(e.target.checked)} />
        <Sparkles size={14} aria-hidden />
        <span>Always interpret my search with AI</span>
        <span className="hint">Slower, handles plain-language requests</span>
      </label>
    </div>
  );
}
