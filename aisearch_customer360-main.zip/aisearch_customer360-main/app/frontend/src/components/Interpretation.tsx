import { Sparkles, Zap } from "lucide-react";
import type { Parsed, SearchResponse } from "../types";
import { label } from "../format";

function chips(p: Parsed): { k: string; v: string }[] {
  const c: { k: string; v: string }[] = [];
  if (p.name_query) c.push({ k: "Name", v: p.name_query });
  if (p.name_alternatives.length) c.push({ k: "Also tried", v: p.name_alternatives.join(", ") });
  if (p.email) c.push({ k: "Email", v: p.email });
  if (p.phone) c.push({ k: "Phone digits", v: p.phone });
  if (p.member_id) c.push({ k: "ID", v: p.member_id });
  if (p.semantic_query) c.push({ k: "Notes and cases about", v: p.semantic_query });
  if (p.tiers.length) c.push({ k: "Tier", v: p.tiers.join(" or ") });
  if (p.states.length) c.push({ k: "State", v: p.states.join(", ") });
  if (p.cities.length) c.push({ k: "City", v: p.cities.join(", ") });
  if (p.statuses.length) c.push({ k: "Status", v: p.statuses.join(", ") });
  if (p.segments.length) c.push({ k: "Segment", v: p.segments.map(label).join(", ") });
  if (p.join_after || p.join_before) c.push({ k: "Joined", v: `${p.join_after ?? "any time"} to ${p.join_before ?? "today"}` });
  if (p.categories.length) c.push({ k: "Case type", v: p.categories.map(label).join(", ") });
  if (p.case_status) c.push({ k: "Case", v: p.case_status });
  if (p.sentiment.length) c.push({ k: "Tone", v: p.sentiment.join(", ") });
  if (p.channels.length) c.push({ k: "Channel", v: p.channels.join(", ") });
  if (p.interaction_since || p.interaction_until)
    c.push({ k: "Contact between", v: `${p.interaction_since ?? "any time"} and ${p.interaction_until ?? "today"}` });
  return c;
}

export function Interpretation({ res }: { res: SearchResponse }) {
  const p = res.parsed;
  const ai = p.source === "llm";
  const t = res.timings_ms;
  return (
    <section className={`interp ${ai ? "ai" : ""}`} aria-label="How the search was understood">
      <div className="interp-main">
        <span className="interp-icon" aria-hidden>
          {ai ? <Sparkles size={16} /> : <Zap size={16} />}
        </span>
        <div>
          <p className="interp-text">
            <strong>{ai ? "AI understood your request as: " : "Searching for: "}</strong>
            {p.explanation || res.query}
          </p>
          {chips(p).length > 0 && (
            <ul className="chips">
              {chips(p).map((c) => (
                <li key={c.k + c.v}>
                  <span>{c.k}</span> {c.v}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="interp-meta">
        <strong>{res.latency_ms} ms</strong>
        <span>{res.engines.join(", ") || "no engine called"}</span>
        <span className="timings">
          {Object.entries(t)
            .map(([k, v]) => `${label(k)} ${v} ms`)
            .join("  ")}
        </span>
      </div>
    </section>
  );
}
