import type { Filters } from "../api";

const TIERS = ["platinum", "gold", "silver", "bronze"];
const STATUSES = ["active", "inactive", "suspended"];
const STATES = ["TX", "OH", "CA", "NY", "FL", "IL", "GA", "WA", "MA", "AZ"];

function toggle(list: string[], v: string) {
  return list.includes(v) ? list.filter((x) => x !== v) : [...list, v];
}

export function FacetPanel({ filters, onChange }: { filters: Filters; onChange: (f: Filters) => void }) {
  const group = (title: string, key: keyof Filters, values: string[]) => (
    <fieldset>
      <legend>{title}</legend>
      {values.map((v) => (
        <label key={v} className="check">
          <input type="checkbox" checked={filters[key].includes(v)} onChange={() => onChange({ ...filters, [key]: toggle(filters[key], v) })} />
          <span>{v}</span>
        </label>
      ))}
    </fieldset>
  );
  const active = filters.tiers.length + filters.states.length + filters.statuses.length;
  return (
    <aside className="facets" aria-label="Filters">
      <div className="facethead">
        <h2>Filters</h2>
        {active > 0 && (
          <button className="link" onClick={() => onChange({ tiers: [], states: [], statuses: [] })}>
            Clear all
          </button>
        )}
      </div>
      {group("Tier", "tiers", TIERS)}
      {group("Status", "statuses", STATUSES)}
      <fieldset className="statelist">
        <legend>State</legend>
        {STATES.map((v) => (
          <label key={v} className="check inline">
            <input type="checkbox" checked={filters.states.includes(v)} onChange={() => onChange({ ...filters, states: toggle(filters.states, v) })} />
            <span>{v}</span>
          </label>
        ))}
      </fieldset>
    </aside>
  );
}
