import { useEffect, useMemo, useState } from "react";
import { FileText, Headset, Package, X } from "lucide-react";
import { getProfile } from "../api";
import type { Profile } from "../types";
import { day, daysAgo, initials, label, money, money2 } from "../format";

type TimelineItem = {
  key: string; at: string; kind: "note" | "case"; title: string; text: string; sentiment?: string;
  channel?: string; status?: string; priority?: string; resolution?: string | null;
};

const HEALTH: Record<string, string> = {
  healthy: "No open issues",
  watch: "Needs attention: an open case or recent unhappy contact",
  at_risk: "At risk: open case and repeated unhappy contacts in the last 90 days",
};

export function ProfilePanel({ memberId, onClose }: { memberId: string; onClose: () => void }) {
  const [data, setData] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<"timeline" | "orders">("timeline");

  useEffect(() => {
    const ctrl = new AbortController();
    setData(null);
    setError(null);
    getProfile(memberId, ctrl.signal).then(setData).catch((e) => e.name !== "AbortError" && setError(e.message));
    return () => ctrl.abort();
  }, [memberId]);

  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const timeline = useMemo<TimelineItem[]>(() => {
    if (!data) return [];
    const items: TimelineItem[] = [
      ...data.cases.map((c) => ({
        key: c.case_id, at: c.opened_at, kind: "case" as const, title: c.subject, text: c.description,
        status: c.status, priority: c.priority, channel: c.channel, resolution: c.resolution,
      })),
      ...data.notes.map((n) => ({
        key: n.note_id, at: n.created_at, kind: "note" as const, title: label(n.category), text: n.note_text,
        sentiment: n.sentiment, channel: n.channel,
      })),
    ];
    return items.sort((a, b) => (a.at < b.at ? 1 : -1));
  }, [data]);

  const m = data?.member;
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <aside className="panel" role="dialog" aria-modal="true" aria-label="Member profile">
        <button className="iconbtn close" onClick={onClose} aria-label="Close profile"><X size={20} /></button>
        {error && <p className="error">Could not load this profile: {error}</p>}
        {!data && !error && <div className="skeleton" aria-busy="true" aria-label="Loading profile" />}
        {m && data && (
          <>
            <header className="phead">
              <span className={`avatar lg tier-${m.tier}`}>{initials(m.full_name)}</span>
              <div>
                <h2>{m.full_name}</h2>
                <p className="mono idline">{m.member_id}</p>
                <p className="tags">
                  <span className={`pill tier-${m.tier}`}>{m.tier}</span>
                  <span className={`status ${m.status}`}>{m.status}</span>
                  <span className="seg">{label(m.segment)}</span>
                </p>
              </div>
            </header>

            <p className={`health ${m.health}`}>
              <strong>{label(m.health)}</strong> {HEALTH[m.health]}
            </p>

            <dl className="facts">
              <div><dt>Email</dt><dd>{m.email}</dd></div>
              <div><dt>Phone</dt><dd className="mono">{m.phone}</dd></div>
              <div><dt>Address</dt><dd>{m.street}, {m.city}, {m.state} {m.zip}</dd></div>
              <div><dt>Member since</dt><dd>{day(m.join_date)}</dd></div>
              <div><dt>Date of birth</dt><dd>{day(m.dob)}</dd></div>
              <div><dt>Source IDs</dt><dd className="mono">{m.source_ids.join("  ")}</dd></div>
            </dl>

            <dl className="kpis">
              <div><dt>Lifetime value</dt><dd>{money(m.lifetime_value)}</dd></div>
              <div><dt>Orders in 12 months</dt><dd>{m.orders_12m}</dd></div>
              <div><dt>Open cases</dt><dd>{m.open_cases} of {m.total_cases}</dd></div>
              <div><dt>Last contact</dt><dd>{daysAgo(m.last_contact_at)}</dd></div>
            </dl>

            <div className="tabs" role="tablist">
              <button role="tab" aria-selected={tab === "timeline"} onClick={() => setTab("timeline")}>
                Contact history <span className="count">{timeline.length}</span>
              </button>
              <button role="tab" aria-selected={tab === "orders"} onClick={() => setTab("orders")}>
                Orders <span className="count">{data.orders.length}</span>
              </button>
            </div>

            {tab === "timeline" ? (
              <ol className="timeline">
                {timeline.length === 0 && <li className="empty">No contact history for this member.</li>}
                {timeline.map((t) => (
                  <li key={t.key} className={t.kind}>
                    <span className="marker" aria-hidden>{t.kind === "case" ? <FileText size={14} /> : <Headset size={14} />}</span>
                    <div>
                      <p className="titleline">
                        <strong>{t.title}</strong>
                        {t.kind === "case" && <span className={`status ${t.status}`}>{t.status}</span>}
                        {t.kind === "case" && <span className="seg">{t.priority} priority</span>}
                        {t.sentiment && <span className={`tone ${t.sentiment}`}>{t.sentiment}</span>}
                      </p>
                      <p className="when">{t.kind === "case" ? "Case" : "Contact note"} via {t.channel}, {day(t.at)}</p>
                      <p className="body">{t.text}</p>
                      {t.resolution && <p className="body resolution">Resolution: {t.resolution}</p>}
                    </div>
                  </li>
                ))}
              </ol>
            ) : (
              <table className="orders">
                <thead><tr><th>Order</th><th>Date</th><th>Category</th><th>Status</th><th className="num">Amount</th></tr></thead>
                <tbody>
                  {data.orders.map((o) => (
                    <tr key={o.order_id}>
                      <td className="mono"><Package size={12} aria-hidden /> {o.order_id}</td>
                      <td>{day(o.order_date)}</td>
                      <td>{o.product_category}</td>
                      <td>{label(o.status)}</td>
                      <td className="num">{money2(o.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </>
        )}
      </aside>
    </>
  );
}
