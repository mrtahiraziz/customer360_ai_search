import { Mail, MapPin, Phone, Quote } from "lucide-react";
import type { MemberHit } from "../types";
import { day, initials, label } from "../format";

export function Results({ hits, onOpen }: { hits: MemberHit[]; onOpen: (id: string) => void }) {
  const top = Math.max(...hits.map((h) => h.score), 0.000001);
  return (
    <ol className="results">
      {hits.map((h) => (
        <li key={h.member_id}>
          <button className="row" onClick={() => onOpen(h.member_id)}>
            <span className={`avatar tier-${h.tier}`} aria-hidden>
              {initials(h.full_name)}
            </span>
            <span className="rowbody">
              <span className="rowhead">
                <span className="name">{h.full_name}</span>
                <span className="mono id">{h.member_id}</span>
                <span className={`pill tier-${h.tier}`}>{h.tier}</span>
                <span className={`status ${h.status}`}>{h.status}</span>
              </span>
              <span className="contact">
                <span><Mail size={13} aria-hidden /> {h.email}</span>
                <span className="mono"><Phone size={13} aria-hidden /> {h.phone}</span>
                <span><MapPin size={13} aria-hidden /> {h.city}, {h.state}</span>
                <span>{label(h.segment)}</span>
              </span>
              {h.matched_on.length > 0 && (
                <span className="badges">
                  {h.matched_on.map((m) => (
                    <span className="badge" key={m}>{m}</span>
                  ))}
                </span>
              )}
              {h.snippets.map((s) => (
                <span className="snippet" key={s.interaction_id}>
                  <Quote size={13} aria-hidden />
                  <span>
                    <span className="snipmeta">
                      {label(s.source_type)} on {day(s.created_at)}
                      {s.category ? `, ${label(s.category)}` : ""}
                    </span>
                    {s.text}
                  </span>
                </span>
              ))}
            </span>
            {top > 0.000001 && h.score > 0 && (
              <span className="relevance" title="Relevance relative to the best match">
                <span style={{ height: `${Math.max(8, Math.round((h.score / top) * 100))}%` }} />
              </span>
            )}
          </button>
        </li>
      ))}
    </ol>
  );
}
