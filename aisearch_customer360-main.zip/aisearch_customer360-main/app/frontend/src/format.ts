export const label = (s: string | null | undefined) => (s ? s.replace(/_/g, " ") : "");

export function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}

export function money(n: number) {
  return n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
}

export function money2(n: number) {
  return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
}

export function day(iso: string | null | undefined) {
  if (!iso) return "none";
  const d = new Date(iso.length <= 10 ? iso + "T00:00:00" : iso.replace(" ", "T"));
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function daysAgo(iso: string | null | undefined, today = new Date("2026-11-22T00:00:00")) {
  if (!iso) return "never";
  const d = new Date(iso.length <= 10 ? iso + "T00:00:00" : iso.replace(" ", "T"));
  const n = Math.round((today.getTime() - d.getTime()) / 86_400_000);
  if (n <= 0) return "today";
  if (n === 1) return "yesterday";
  if (n < 60) return `${n} days ago`;
  return `${Math.round(n / 30)} months ago`;
}
