import type { Profile, SearchResponse } from "./types";

async function parse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = res.statusText;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* body was not JSON */
    }
    throw new Error(detail);
  }
  return res.json() as Promise<T>;
}

export type Filters = { tiers: string[]; states: string[]; statuses: string[] };

export function search(query: string, useAi: boolean, filters: Filters, signal?: AbortSignal) {
  return fetch("/api/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, use_ai: useAi, ...filters }),
    signal,
  }).then((r) => parse<SearchResponse>(r));
}

export function typeahead(q: string, signal?: AbortSignal) {
  return fetch(`/api/typeahead?q=${encodeURIComponent(q)}`, { signal }).then((r) => parse<SearchResponse>(r));
}

export function getProfile(memberId: string, signal?: AbortSignal) {
  return fetch(`/api/members/${encodeURIComponent(memberId)}`, { signal }).then((r) => parse<Profile>(r));
}

export function whoAmI() {
  return fetch("/api/me").then((r) => parse<{ user: string }>(r));
}
