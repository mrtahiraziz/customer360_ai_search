import { useCallback, useEffect, useRef, useState } from "react";
import { search, whoAmI, type Filters } from "./api";
import type { SearchResponse } from "./types";
import { SearchBox } from "./components/SearchBox";
import { Interpretation } from "./components/Interpretation";
import { Results } from "./components/Results";
import { FacetPanel } from "./components/FacetPanel";
import { ProfilePanel } from "./components/ProfilePanel";

const EXAMPLES: { group: string; items: { q: string; why: string }[] }[] = [
  {
    group: "Names with typos, nicknames and accents",
    items: [
      { q: "Jon Smyth", why: "Finds John, Jon and Jonathan Smith by sound" },
      { q: "bob chen", why: "Knows Bob is short for Robert" },
      { q: "Jose Garcia", why: "Matches José García with or without accents" },
    ],
  },
  {
    group: "Contact details in any format",
    items: [
      { q: "john.smith@gmail", why: "Part of an email address" },
      { q: "972 718 3898", why: "Phone number written any way you like" },
    ],
  },
  {
    group: "Plain-language requests",
    items: [
      { q: "gold members in Ohio who joined in 2025", why: "Becomes filters on tier, state and join date" },
      { q: "customers who were charged twice and are still waiting for a refund", why: "Searches notes and cases by meaning" },
      { q: "platinum members in Texas with an open case about delivery delays in the last 90 days", why: "Filters plus notes and cases" },
    ],
  },
];

export default function App() {
  const [query, setQuery] = useState("");
  const [useAi, setUseAi] = useState(false);
  const [filters, setFilters] = useState<Filters>({ tiers: [], states: [], statuses: [] });
  const [res, setRes] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [user, setUser] = useState("");
  const lastQuery = useRef("");
  const ctrl = useRef<AbortController | null>(null);

  useEffect(() => {
    whoAmI().then((r) => setUser(r.user)).catch(() => undefined);
  }, []);

  const run = useCallback(
    (q: string, f: Filters, ai: boolean) => {
      ctrl.current?.abort();
      const c = new AbortController();
      ctrl.current = c;
      lastQuery.current = q;
      setBusy(true);
      setError(null);
      search(q, ai, f, c.signal)
        .then((r) => setRes(r))
        .catch((e) => e.name !== "AbortError" && setError(e.message))
        .finally(() => !c.signal.aborted && setBusy(false));
    },
    [],
  );

  const submit = (q: string) => run(q, filters, useAi);
  const changeFilters = (f: Filters) => {
    setFilters(f);
    if (lastQuery.current) run(lastQuery.current, f, useAi);
  };
  const tryExample = (q: string) => {
    setQuery(q);
    run(q, filters, useAi);
  };

  return (
    <div className="app">
      <header className="topbar">
        <span className="brand">Member search</span>
        <span className="topmeta">
          Demo with synthetic data{user && user !== "local-dev" ? `, signed in as ${user}` : ""}
        </span>
      </header>

      <main>
        <h1 className="sr-only">Find a member</h1>
        <SearchBox
          value={query}
          onChange={setQuery}
          onSubmit={submit}
          onOpenMember={setOpenId}
          useAi={useAi}
          onToggleAi={setUseAi}
          busy={busy}
        />

        {error && (
          <p className="error" role="alert">
            Search failed: {error}. Check your connection and try again.
          </p>
        )}

        {res && <Interpretation res={res} />}

        {res ? (
          <div className="layout">
            <FacetPanel filters={filters} onChange={changeFilters} />
            <section aria-live="polite" aria-busy={busy}>
              <p className="count-line">
                {res.total === 0 ? "No members found" : `${res.total} ${res.total === 1 ? "member" : "members"}`}
              </p>
              {res.message && <p className="notice">{res.message}</p>}
              {res.total === 0 && !res.message && (
                <div className="empty-results">
                  <p>
                    Nothing matched. Try fewer words, check the spelling, or turn on AI interpretation to search by
                    description.
                  </p>
                </div>
              )}
              <Results hits={res.results} onOpen={setOpenId} />
            </section>
          </div>
        ) : (
          <section className="examples" aria-label="Example searches">
            <h2>Try a search</h2>
            <div className="example-groups">
              {EXAMPLES.map((g) => (
                <div key={g.group}>
                  <h3>{g.group}</h3>
                  <ul>
                    {g.items.map((it) => (
                      <li key={it.q}>
                        <button onClick={() => tryExample(it.q)}>
                          <span className="q">{it.q}</span>
                          <span className="why">{it.why}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      {openId && <ProfilePanel memberId={openId} onClose={() => setOpenId(null)} />}
    </div>
  );
}
