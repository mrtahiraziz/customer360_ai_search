# Deployment steps

Deploy the **Customer 360 Member Search** demo into your own Databricks workspace. It is a Databricks App (FastAPI + React) that uses **AI Search** (Vector Search) and a **Foundation Model API** LLM, all on synthetic data.

**Time needed:** about 1 to 1.5 hours, most of it waiting for the AI Search endpoint and indexes to provision. Your own hands-on time is about 20 minutes.

**What you will end up with** (all names can be changed, see step 2):

| Object | Default name |
|---|---|
| Schema (in a catalog you choose) | `<catalog>.customer360_search` |
| Volume for the source files | `<catalog>.customer360_search.staging` |
| 11 Delta tables (5 raw, 5 Gold, 1 audit) | see step 4 |
| AI Search endpoint | `c360-search-ep` |
| 2 AI Search indexes | `member_search_idx`, `interaction_search_idx` |
| Databricks App | `c360-member-search` |

How the pieces fit together: see `docs/diagrams/01_architecture_data_flow.png`. How each search is routed: `docs/diagrams/02_query_routing.png`. After deploying, follow [`DEMO_SCRIPT.md`](DEMO_SCRIPT.md) to test every scenario.

---

## 0. Prerequisites

### In your workspace
| Need | How to check |
|---|---|
| Unity Catalog, and a catalog where you can create a schema | You need `USE CATALOG` and `CREATE SCHEMA` on it |
| An existing **serverless SQL warehouse** you can use (`CAN_USE`) | Step 2 shows how to list them. No new warehouse is created |
| **AI Search (Vector Search)** available, and permission to create an endpoint | Catalog Explorer, or Compute > Vector Search |
| **Foundation Model APIs** enabled with a chat model, plus the embedding model `databricks-gte-large-en` | Serving page, endpoints starting with `databricks-` |
| **Databricks Apps** enabled, and permission to create an app | Compute > Apps |

> The default chat model is `databricks-claude-haiku-4-5`. If it is not available in your region, any chat model from the Foundation Model API works (for example a Llama or GPT endpoint). Set it in step 2 and in `app/app.yaml` (step 11). The app only needs the model to return a JSON object.

### On your computer
| Tool | Version | Check |
|---|---|---|
| Databricks CLI | recent (tested with 1.20.0) | `databricks --version` |
| [uv](https://docs.astral.sh/uv/) | any recent | `uv --version` |
| Python | 3.12 (uv installs it for you) | `uv python list` |
| Node.js + npm | 18 or newer. **Only needed if you change the UI.** The built UI is already in `app/static` | `node --version` |
| git | any | `git --version` |

---

## 1. Get the code and install dependencies

```bash
git clone https://github.com/tahir-aziz_data/aisearch_customer360.git
cd aisearch_customer360
uv sync
```

`uv sync` creates `.venv` with Python 3.12 and installs the packages from `uv.lock`.

---

## 2. Choose your settings (environment variables)

You do **not** need to edit any Python file. Set these in the terminal you will use for all the steps below:

```bash
export DATABRICKS_CONFIG_PROFILE=<your-cli-profile>   # the profile from step 3
export C360_PROFILE=$DATABRICKS_CONFIG_PROFILE         # used when you run the app locally
export C360_CATALOG=<an-existing-catalog>              # you must be able to create a schema in it
export C360_SCHEMA=customer360_search                  # created for you in step 4
export C360_WAREHOUSE_ID=<serverless-warehouse-id>     # see below
```

Optional (defaults shown):

```bash
export C360_LLM_ENDPOINT=databricks-claude-haiku-4-5
export C360_SEARCH_ENDPOINT=c360-search-ep
export C360_APP_NAME=c360-member-search
```

**Find a serverless warehouse ID** (after step 3):

```bash
databricks warehouses list -o json | python3 -c "
import sys,json
for w in json.load(sys.stdin):
    if w.get('enable_serverless_compute'): print(w['id'], '|', w['name'], '|', w.get('state'))"
```

A stopped warehouse is fine; it starts automatically on the first query.

> **New terminal?** Re-run these `export` lines. They only last for that terminal session.

---

## 3. Log in to your workspace

```bash
databricks auth login --host https://<your-workspace>.cloud.databricks.com --profile $DATABRICKS_CONFIG_PROFILE
databricks current-user me -o json | python3 -c "import sys,json;print(json.load(sys.stdin)['userName'])"
```

The second command should print your email. If it fails, the profile or login is wrong. Fix this before continuing.

---

## 4. Create the schema, load the data and build the Gold tables

```bash
uv run python setup/01_load_and_build_gold.py
```

What it does (all idempotent, safe to re-run):

0. Creates the schema and the `staging` volume.
1. Uploads the five synthetic Parquet files from `build/data/` to the volume.
2. Loads them as raw Delta tables.
3. Builds the Gold tables: `member_golden`, `first_name_aliases`, `member_search_doc`, `member_interactions`, `member_profile`, and the empty `search_events` audit table. Change Data Feed is enabled on the two tables that feed the indexes.

**Expected output** (the last block). The counts must match, otherwise the data did not load correctly:

```
  members_source           10,000
  member_golden            10,000
  member_search_doc        10,000
  member_interactions      47,466
  member_orders            32,013
  member_cases             12,599
  member_notes             34,867
```

Takes about 1 to 3 minutes (plus warehouse start-up).

---

## 5. Create the AI Search endpoint

```bash
uv run python setup/00_create_endpoint.py
```

It creates a dedicated STANDARD endpoint and waits until its state is `ONLINE`. **This takes 15 to 20 minutes the first time.** The script prints the state every 20 seconds. If you want, run step 5 in a second terminal while you do step 4.

If the endpoint already exists it is reused.

---

## 6. Create the two AI Search indexes

```bash
uv run python setup/02_create_indexes.py
```

This creates two Delta Sync indexes (hybrid, with managed embeddings from `databricks-gte-large-en`) and waits for both:

| Index | Source table | Rows when ready |
|---|---|---|
| `member_search_idx` | `member_search_doc` | 10,000 |
| `interaction_search_idx` | `member_interactions` | 47,466 |

Takes **10 to 40 minutes**. The script prints progress like `ready=False rows=27250` every 30 seconds. Wait until both show `ready=True` with the full row counts.

If the script times out, it is safe to run again. Existing indexes are kept, and it just resumes waiting.

> Only run step 6 once step 4 and step 5 are finished. The indexes need the tables and the endpoint.

---

## 7. (Optional) Refresh the lookup files used by the app

```bash
uv run python setup/03_export_aliases.py
```

This rewrites `app/backend/aliases.json` (nickname map) and `app/backend/vocab.json` (name vocabulary for typeahead) from your Gold tables. The files in the repo are already correct for the provided data, so **skip this step** unless you change the data.

---

## 8. Test locally before deploying

Start the backend (leave it running):

```bash
cd app
C360_CATALOG=$C360_CATALOG C360_SCHEMA=$C360_SCHEMA C360_WAREHOUSE_ID=$C360_WAREHOUSE_ID \
  uv run --project .. uvicorn backend.main:app --host 127.0.0.1 --port 8010
```

In a second terminal (from the repo root, with the step 2 variables set):

```bash
curl -s localhost:8010/api/health
uv run python tests/smoke.py http://127.0.0.1:8010 "Jon Smyth" "john.smith@gmail" "gold members in Ohio who joined in 2025" "customers who were charged twice and are still waiting for a refund"
```

Expected:

- `/api/health` returns `{"status":"ok", ... "member_index":"<catalog>.<schema>.member_search_idx" ...}`.
- `Jon Smyth` returns Jon Smyth first, then John Smyth, Johnny Smythe and John Smith.
- The last query returns members with open billing-dispute cases and a quoted note.

Open http://127.0.0.1:8010 in a browser to see the UI. Stop the backend with Ctrl+C when done.

---

## 9. Create the Databricks App

The app needs three **resources** so that its service principal can use the warehouse and the two model endpoints. Create the app with them in one command:

```bash
cat > /tmp/c360_app.json <<EOF
{
  "name": "${C360_APP_NAME:-c360-member-search}",
  "description": "Customer 360 member search (AI Search + LLM parser, synthetic data)",
  "resources": [
    {"name": "sql-warehouse", "sql_warehouse": {"id": "$C360_WAREHOUSE_ID", "permission": "CAN_USE"}},
    {"name": "llm", "serving_endpoint": {"name": "${C360_LLM_ENDPOINT:-databricks-claude-haiku-4-5}", "permission": "CAN_QUERY"}},
    {"name": "embedding", "serving_endpoint": {"name": "databricks-gte-large-en", "permission": "CAN_QUERY"}}
  ]
}
EOF
databricks apps create --json @/tmp/c360_app.json
```

- The resource names (`sql-warehouse`, `llm`, `embedding`) must stay exactly as written. `app/app.yaml` refers to `sql-warehouse`.
- The command waits for the app compute to start. This takes a few minutes. The app is empty until step 12, so do not worry if it shows an error page.
- Do not pass the app name as a separate argument. It is already in the JSON.

Note the app's service principal and URL:

```bash
databricks apps get ${C360_APP_NAME:-c360-member-search} -o json | python3 -c "
import sys,json;d=json.load(sys.stdin)
print('service principal:', d['service_principal_client_id']); print('url:', d['url'])"
```

---

## 10. Give the app's service principal access to the data

The app runs as its own service principal. It needs read access to the tables and indexes, and write access to the audit table:

```bash
uv run python setup/04_grant_app.py
```

This runs (using the service principal id from step 9):

```sql
GRANT USE CATALOG ON CATALOG <catalog> TO `<service-principal-client-id>`;
GRANT USE SCHEMA, SELECT ON SCHEMA <catalog>.<schema> TO `<service-principal-client-id>`;
GRANT MODIFY ON TABLE <catalog>.<schema>.search_events TO `<service-principal-client-id>`;
```

`SELECT` on the schema covers the Gold tables **and** both AI Search indexes (they are Unity Catalog objects inside the schema). You need the right to grant these (catalog or schema owner, or `MANAGE`). If you don't have it, ask an admin to run those three statements.

The warehouse and model-endpoint access were already granted by the app resources in step 9.

---

## 11. Point the app at your catalog and schema

Open `app/app.yaml` and change the two lines that name the catalog and schema:

```yaml
command: ["uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000"]

env:
  - name: C360_WAREHOUSE_ID
    valueFrom: sql-warehouse          # leave as is: comes from the app resource
  - name: C360_LLM_ENDPOINT
    value: databricks-claude-haiku-4-5   # change if you chose a different chat model
  - name: C360_CATALOG
    value: <your-catalog>             # CHANGE: same as $C360_CATALOG
  - name: C360_SCHEMA
    value: customer360_search         # CHANGE only if you used a different schema name
```

If you chose a different chat model in step 2, the value here and the `llm` resource in step 9 must name the **same** endpoint.

---

## 12. Upload the code and deploy

```bash
ME=$(databricks current-user me -o json | python3 -c "import sys,json;print(json.load(sys.stdin)['userName'])")
APP_DIR=/Workspace/Users/$ME/${C360_APP_NAME:-c360-member-search}

cd app
databricks sync . "$APP_DIR" --exclude "frontend/**" --exclude "__pycache__" --exclude ".venv" --full
databricks apps deploy ${C360_APP_NAME:-c360-member-search} --source-code-path "$APP_DIR"
cd ..
```

- `app/static` (the built UI) is uploaded. `app/frontend` (UI source) is not needed at runtime and is excluded.
- Deployment takes 1 to 2 minutes. Success looks like `"state": "SUCCEEDED"` and `"message": "App started successfully"`.

---

## 13. Verify the deployed app

**In the browser:** run

```bash
databricks apps get ${C360_APP_NAME:-c360-member-search} -o json | python3 -c "import sys,json;print(json.load(sys.stdin)['url'])"
```

and open the URL (it looks like `https://<app-name>-<workspace-id>.<n>.azure.databricksapps.com`, or `.aws.databricksapps.com` on AWS). Sign in with your workspace account. Try `Jon Smyth`.

**From the command line** (checks the whole stack, including the LLM and the audit write):

```bash
TOKEN=$(databricks auth token -o json | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
APP_URL=$(databricks apps get ${C360_APP_NAME:-c360-member-search} -o json | python3 -c "import sys,json;print(json.load(sys.stdin)['url'])")

curl -s -H "Authorization: Bearer $TOKEN" $APP_URL/api/health
curl -s -H "Authorization: Bearer $TOKEN" -X POST $APP_URL/api/search -H 'content-type: application/json' \
  -d '{"query":"gold members in Ohio who joined in 2025"}' | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('detail') or (d['total'], d['parsed']['source'], d['engines']))"
```

Expected: `/api/health` shows `"in_app":true`, and the search prints about `13 llm ['AI Search (filter)']`.

**Check the audit table** (should show your search with your email):

```sql
SELECT user_email, query_text, intent, latency_ms, event_ts
FROM <catalog>.<schema>.search_events ORDER BY event_ts DESC LIMIT 10;
```

Now run through [`DEMO_SCRIPT.md`](DEMO_SCRIPT.md).

---

## 14. Share the app with others (optional)

By default only you can open it. To let colleagues use it, grant them `CAN_USE` on the app (**Compute > Apps > your app > Permissions**), or with the CLI:

```bash
databricks apps update-permissions ${C360_APP_NAME:-c360-member-search} --json '{
  "access_control_list": [{"user_name": "colleague@example.com", "permission_level": "CAN_USE"}]
}'
```

They do **not** need access to the catalog, warehouse or AI Search. The app reads data as its own service principal.

---

## Updating the app later

| Change | What to do |
|---|---|
| Backend code (`app/backend/*.py`) | Run the sync and deploy commands from step 12 |
| UI code (`app/frontend/src/*`) | `cd app/frontend && npm install && npx vite build`, then step 12 |
| Source data or Gold tables | Re-run step 4, then re-sync the indexes (below), then step 7 |
| `app/app.yaml` values | Step 12 (redeploy) |

**Re-sync an index after the table changes** (the indexes use TRIGGERED sync, so they do not update on their own):

```bash
uv run python - <<'EOF'
import sys; sys.path.insert(0, "setup")
from dbx import client; import config
for n in (config.MEMBER_INDEX, config.INTERACTION_INDEX):
    client().vector_search_indexes.sync_index(n); print("sync started:", n)
EOF
```

**Regenerate the synthetic data** (optional, only if you want different data. The demo script's expected results assume the data in the repo):

```bash
uv run python data_gen/generate_data.py
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Step 4: `SQL failed: ... PERMISSION_DENIED` or `CREATE SCHEMA` error | No `CREATE SCHEMA` on the catalog | Ask the catalog owner, or choose another catalog |
| Step 4: `warehouse ... not found` / cannot start | Wrong `C360_WAREHOUSE_ID`, or no `CAN_USE` | Re-list warehouses (step 2) and pick one you can use |
| Step 5 is slow | Normal: 15 to 20 minutes the first time | Wait |
| Step 5: quota or entitlement error | AI Search not enabled, or endpoint limit reached | Ask your workspace admin, or delete an unused endpoint |
| Step 6: `Invalid column type timestamp_ntz` | Only if you edited the table SQL | Keep `CAST(created_at AS TIMESTAMP)` in `member_interactions` |
| Step 6: index stuck at a low row count | Embedding is still running | Keep waiting. The interaction index (47k rows) is the slow one |
| Step 6: `index_subtype=HYBRID rejected` message, then continues | Your region does not accept the subtype option | Harmless: the script retries with the default index type, which still answers hybrid queries |
| App page shows an error or the logs show `ModuleNotFoundError` | Code not synced, or `app/requirements.txt` missing | Re-run step 12 and check `databricks apps logs <app-name> --tail-lines 100` |
| `/api/health` works but every search returns `Search failed: ... PERMISSION_DENIED` | Service principal grants missing | Re-run step 10 |
| Searches work but `search_events` stays empty | `MODIFY` on `search_events` missing | Re-run step 10 (audit failures are silent by design) |
| `Search failed: ... exceeds the maximum allowed limit of 50 when using reranking` | You changed result counts in `search.py` | Keep `num_results` at 50 or less for reranked queries |
| Sentences like "gold members in Ohio" return name matches | The LLM call failed, so the app fell back to keyword search | Check that the `llm` resource and `C360_LLM_ENDPOINT` name the same, working endpoint. See app logs for `[parser] LLM parse failed` |
| `curl` to the app returns an empty body or a login page | Wrong URL or token | Use the `url` from `databricks apps get` (it is not the workspace URL) and a fresh token |
| First search after idle takes 5 to 10 seconds | Cold start of the warehouse or app | Run it again |
| Expected results in `DEMO_SCRIPT.md` differ | Different data, or the model reads a sentence differently | Check the row counts in step 4. LLM output can vary slightly. Names, IDs and notes searches should match |

---

## Clean up (stop all charges)

The **AI Search endpoint** and the **warehouse** are the parts that cost money while they exist or run. When you are done:

```bash
# 1. The app
databricks apps delete ${C360_APP_NAME:-c360-member-search}

# 2. The indexes and the endpoint
uv run python - <<'EOF'
import sys; sys.path.insert(0, "setup")
from dbx import client; import config
w = client()
for n in (config.MEMBER_INDEX, config.INTERACTION_INDEX):
    w.vector_search_indexes.delete_index(n); print("deleted", n)
w.vector_search_endpoints.delete_endpoint(config.SEARCH_ENDPOINT); print("deleted endpoint", config.SEARCH_ENDPOINT)
EOF

# 3. The data (tables, volume and schema)
databricks schemas delete $C360_CATALOG.$C360_SCHEMA --force
```

Your own warehouse and catalog are not touched.

---

## Reference: what each file does

| File | Purpose |
|---|---|
| `config.py` | Settings for the setup scripts (reads the `C360_*` environment variables) |
| `build/data/*.parquet` | The synthetic source data (10,000 members, orders, cases, notes, nicknames) |
| `data_gen/` | Generator that produced those Parquet files (optional) |
| `setup/01_load_and_build_gold.py` | Schema, volume, raw tables, Gold tables |
| `setup/00_create_endpoint.py` | AI Search endpoint |
| `setup/02_create_indexes.py` | The two AI Search indexes |
| `setup/03_export_aliases.py` | Nickname and vocabulary files for the app |
| `setup/04_grant_app.py` | Service principal grants for the app |
| `app/app.yaml`, `app/requirements.txt` | How Databricks Apps runs the app |
| `app/backend/` | FastAPI: parser, search router, profile, clients |
| `app/frontend/`, `app/static/` | React source, and the built UI that is served |
| `tests/smoke.py` | Sends sample queries to a running backend |
| `DEMO_SCRIPT.md` | What to type and what you should see |
| `docs/` | Architecture reference and data flow diagrams |
