"""Create the two Delta Sync AI Search indexes on the dedicated endpoint and wait until they are ready."""
import sys
import time

from databricks.sdk.service.vectorsearch import (DeltaSyncVectorIndexSpecRequest, EmbeddingSourceColumn, IndexSubtype,
                                                  PipelineType, VectorIndexType)

from dbx import client
import config

INDEXES = [
    dict(
        name=config.MEMBER_INDEX,
        source=f"{config.FQ}.member_search_doc",
        pk="member_id",
        embed_col="search_text",
        columns=["member_id", "full_name", "search_text", "email", "phone", "phone_e164", "phone_last4", "city",
                 "state", "zip", "tier", "status", "segment", "join_year", "join_day"],
    ),
    dict(
        name=config.INTERACTION_INDEX,
        source=f"{config.FQ}.member_interactions",
        pk="interaction_id",
        embed_col="chunk_text",
        columns=["interaction_id", "member_id", "source_type", "source_id", "title", "chunk_text", "channel",
                 "category", "sentiment", "case_status", "state", "tier", "created_at", "created_day"],
    ),
]


def create(spec: dict):
    w = client()
    try:
        w.vector_search_indexes.get_index(spec["name"])
        print(f"  {spec['name']} already exists")
        return
    except Exception:
        pass
    delta = DeltaSyncVectorIndexSpecRequest(
        source_table=spec["source"],
        pipeline_type=PipelineType.TRIGGERED,
        embedding_source_columns=[EmbeddingSourceColumn(
            name=spec["embed_col"], embedding_model_endpoint_name=config.EMBEDDING_ENDPOINT)],
        columns_to_sync=spec["columns"],
    )
    kwargs = dict(name=spec["name"], endpoint_name=config.SEARCH_ENDPOINT, primary_key=spec["pk"],
                  index_type=VectorIndexType.DELTA_SYNC, delta_sync_index_spec=delta)
    try:
        w.vector_search_indexes.create_index(index_subtype=IndexSubtype.HYBRID, **kwargs)
    except Exception as e:
        if "subtype" not in str(e).lower():
            raise
        # subtype not supported here -> default index type (still answers hybrid queries)
        print(f"  index_subtype=HYBRID rejected ({str(e)[:140]}); retrying without it")
        w.vector_search_indexes.create_index(**kwargs)
    print(f"  created {spec['name']}")


def wait_ready(name: str, timeout_s: int = 1800):
    w = client()
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        idx = w.vector_search_indexes.get_index(name)
        st = idx.status
        msg = (st.message or "")[:110] if st else ""
        print(f"  {name.split('.')[-1]}: ready={st.ready if st else None} rows={st.indexed_row_count if st else None} {msg}")
        if st and st.ready:
            return
        time.sleep(30)
    print(f"  timed out waiting for {name}", file=sys.stderr)


def main():
    for spec in INDEXES:
        create(spec)
    for spec in INDEXES:
        wait_ready(spec["name"])


if __name__ == "__main__":
    main()
