"""Export small lookup files from Gold tables into app/backend/ for query-time expansion.

  aliases.json : nickname map   (bob -> robert, bobby, rob ...)
  vocab.json   : name vocabulary with counts (used to complete the word being typed in typeahead,
                 because AI Search matches whole tokens and has no prefix matching)
"""
import json
from pathlib import Path

from dbx import run_sql
import config

OUT = Path(__file__).resolve().parent.parent / "app" / "backend"
ACC_IN, ACC_OUT = "áàâäãåéèêëíìîïóòôöõúùûüñç", "aaaaaaeeeeiiiiooooouuuunc"


def main():
    rows = run_sql(f"SELECT first_norm, alias FROM {config.FQ}.first_name_aliases ORDER BY first_norm, alias", quiet=True)
    m: dict[str, list[str]] = {}
    for first, alias in rows:
        m.setdefault(first, []).append(alias)
    (OUT / "aliases.json").write_text(json.dumps(m, indent=0, sort_keys=True))
    print(f"aliases.json: {len(m)} names / {len(rows)} aliases")

    vocab_rows = run_sql(f"""
        SELECT w, count(*) AS n FROM (
          SELECT regexp_replace(translate(lower(first_name), '{ACC_IN}', '{ACC_OUT}'), '[^a-z]', '') AS w FROM {config.FQ}.member_golden
          UNION ALL
          SELECT regexp_replace(translate(lower(last_name),  '{ACC_IN}', '{ACC_OUT}'), '[^a-z]', '') FROM {config.FQ}.member_golden
        ) WHERE length(w) >= 2 GROUP BY w ORDER BY n DESC
    """, quiet=True)
    vocab = {w: int(n) for w, n in vocab_rows}
    (OUT / "vocab.json").write_text(json.dumps(vocab, indent=0))
    print(f"vocab.json: {len(vocab)} name tokens")


if __name__ == "__main__":
    main()
