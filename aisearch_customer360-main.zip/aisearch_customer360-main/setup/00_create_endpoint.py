"""Create the dedicated AI Search endpoint (idempotent) and wait until it is ONLINE."""
import time

from databricks.sdk.service.vectorsearch import EndpointType

from dbx import client  # noqa: E402  (must come first: it puts the project root on sys.path)
import config


def main():
    w = client()
    existing = {e.name: e for e in w.vector_search_endpoints.list_endpoints()}
    if config.SEARCH_ENDPOINT in existing:
        print(f"Endpoint {config.SEARCH_ENDPOINT} already exists")
    else:
        print(f"Creating endpoint {config.SEARCH_ENDPOINT} (STANDARD)...")
        w.vector_search_endpoints.create_endpoint(
            name=config.SEARCH_ENDPOINT, endpoint_type=EndpointType.STANDARD
        )
    for _ in range(120):
        e = w.vector_search_endpoints.get_endpoint(config.SEARCH_ENDPOINT)
        state = e.endpoint_status.state.value if e.endpoint_status and e.endpoint_status.state else "?"
        print("  state:", state)
        if state == "ONLINE":
            return
        time.sleep(20)
    raise SystemExit("Endpoint did not become ONLINE in time")


if __name__ == "__main__":
    main()
