"""Small helpers shared by setup scripts."""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState

import config

_w: WorkspaceClient | None = None


def client() -> WorkspaceClient:
    global _w
    if _w is None:
        _w = WorkspaceClient(profile=config.PROFILE)
    return _w


def run_sql(statement: str, *, quiet: bool = False):
    """Run a statement on the configured serverless warehouse and wait for it."""
    w = client()
    resp = w.statement_execution.execute_statement(
        warehouse_id=config.WAREHOUSE_ID,
        statement=statement,
        wait_timeout="50s",
    )
    while resp.status.state in (StatementState.PENDING, StatementState.RUNNING):
        time.sleep(2)
        resp = w.statement_execution.get_statement(resp.statement_id)
    if resp.status.state != StatementState.SUCCEEDED:
        err = resp.status.error
        raise RuntimeError(f"SQL failed: {err.message if err else resp.status.state}\n---\n{statement[:600]}")
    rows = resp.result.data_array if resp.result and resp.result.data_array else []
    if not quiet:
        first = statement.strip().splitlines()[0][:100]
        print(f"  ok: {first}")
    return rows
