"""Give the Databricks App's service principal the Unity Catalog access it needs (idempotent).

Run AFTER `databricks apps create` (the app must exist so it has a service principal).

  USE CATALOG / USE SCHEMA / SELECT on the schema -> reads Gold tables and queries both AI Search indexes
  MODIFY on search_events                          -> lets the app write its audit rows

The SQL warehouse and the two serving endpoints are granted through the app's *resources*, not here.
"""
from dbx import client, run_sql
import config


def main():
    sp = client().apps.get(config.APP_NAME).service_principal_client_id
    if not sp:
        raise SystemExit(f"App {config.APP_NAME} has no service principal yet. Create it first (deployment_steps.md, step 9).")
    print(f"App {config.APP_NAME} service principal: {sp}")
    run_sql(f"GRANT USE CATALOG ON CATALOG {config.CATALOG} TO `{sp}`")
    run_sql(f"GRANT USE SCHEMA, SELECT ON SCHEMA {config.FQ} TO `{sp}`")
    run_sql(f"GRANT MODIFY ON TABLE {config.FQ}.search_events TO `{sp}`")
    print("Grants applied.")


if __name__ == "__main__":
    main()
