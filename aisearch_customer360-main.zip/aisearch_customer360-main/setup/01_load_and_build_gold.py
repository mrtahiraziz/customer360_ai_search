"""Upload synthetic parquet files to a UC volume, load them as Delta tables, and build the Gold layer.

Gold tables (fe_tahir_aziz.customer360_search):
  member_golden, member_search_doc (CDF), member_interactions (CDF), member_profile, search_events
All transformations are SQL on the existing serverless warehouse.
"""
from pathlib import Path

from dbx import client, run_sql
import config

DATA_DIR = Path(__file__).resolve().parent.parent / "build" / "data"
VOL_DIR = f"/Volumes/{config.CATALOG}/{config.SCHEMA}/{config.VOLUME}/data"
FQ = config.FQ

ACCENTS_IN = "áàâäãåéèêëíìîïóòôöõúùûüñç"
ACCENTS_OUT = "aaaaaaeeeeiiiiooooouuuunc"


def upload():
    w = client()
    w.files.create_directory(VOL_DIR)
    for f in sorted(DATA_DIR.glob("*.parquet")):
        print(f"  uploading {f.name} ({f.stat().st_size/1e6:.1f} MB)")
        with open(f, "rb") as fh:
            w.files.upload(f"{VOL_DIR}/{f.name}", fh, overwrite=True)


def load_raw():
    for t in ["members_source", "member_orders", "member_cases", "member_notes", "ref_nicknames"]:
        run_sql(f"""
            CREATE OR REPLACE TABLE {FQ}.{t}
            AS SELECT * FROM read_files('{VOL_DIR}/{t}.parquet', format => 'parquet')
        """)


def build_golden():
    # Alias map: nickname <-> canonical <-> sibling nicknames (lowercase)
    run_sql(f"""
        CREATE OR REPLACE TABLE {FQ}.first_name_aliases AS
        SELECT DISTINCT first_norm, alias FROM (
          SELECT lower(canonical_name) AS first_norm, lower(nickname) AS alias FROM {FQ}.ref_nicknames
          UNION ALL
          SELECT lower(nickname), lower(canonical_name) FROM {FQ}.ref_nicknames
          UNION ALL
          SELECT lower(a.nickname), lower(b.nickname)
          FROM {FQ}.ref_nicknames a JOIN {FQ}.ref_nicknames b
            ON a.canonical_name = b.canonical_name AND a.nickname <> b.nickname
        ) WHERE first_norm <> alias
    """)

    run_sql(f"""
        CREATE OR REPLACE TABLE {FQ}.member_golden
        COMMENT 'Gold: one normalized row per member (names, phone, email standardized for search)'
        AS
        WITH cleaned AS (
          SELECT
            member_id,
            CASE WHEN trim(first_name) = upper(trim(first_name)) OR trim(first_name) = lower(trim(first_name))
                 THEN initcap(trim(first_name)) ELSE trim(first_name) END AS first_name,
            CASE WHEN trim(last_name) = upper(trim(last_name)) OR trim(last_name) = lower(trim(last_name))
                 THEN initcap(trim(last_name)) ELSE trim(last_name) END AS last_name,
            lower(trim(email_raw)) AS email_norm,
            regexp_replace(phone_raw, '[^0-9]', '') AS phone_all_digits,
            dob, street, city, state, zip, tier, status, segment, join_date,
            split(source_ids_raw, '[|]') AS source_ids,
            updated_at
          FROM {FQ}.members_source
        ),
        n AS (
          SELECT *,
            regexp_replace(translate(lower(first_name), '{ACCENTS_IN}', '{ACCENTS_OUT}'), '[^a-z]', '') AS first_ascii,
            regexp_replace(translate(lower(last_name),  '{ACCENTS_IN}', '{ACCENTS_OUT}'), '[^a-z]', '') AS last_ascii,
            substr(phone_all_digits, -10) AS phone_digits
          FROM cleaned
        ),
        al AS (
          SELECT n.member_id, concat_ws(' ', array_sort(collect_set(a.alias))) AS name_aliases
          FROM n JOIN {FQ}.first_name_aliases a ON a.first_norm = n.first_ascii
          GROUP BY n.member_id
        )
        SELECT
          n.member_id, n.first_name, n.last_name,
          concat(n.first_name, ' ', n.last_name) AS full_name,
          concat(n.first_ascii, ' ', n.last_ascii) AS full_name_norm,
          concat_ws(' ', soundex(n.first_ascii), soundex(n.last_ascii)) AS name_phonetic,
          coalesce(al.name_aliases, '') AS name_aliases,
          n.email_norm AS email,
          n.email_norm,
          split_part(n.email_norm, '@', 1) AS email_local,
          regexp_replace(split_part(n.email_norm, '@', 1), '[^a-z0-9]', '') AS email_local_alnum,
          split_part(n.email_norm, '@', 2) AS email_domain,
          concat('+1', n.phone_digits) AS phone_e164,
          n.phone_digits,
          substr(n.phone_digits, -4) AS phone_last4,
          concat('(', substr(n.phone_digits,1,3), ') ', substr(n.phone_digits,4,3), '-', substr(n.phone_digits,7,4)) AS phone_display,
          n.dob, n.street, n.city, n.state, n.zip,
          lower(concat_ws(' ', n.street, n.city, n.state, n.zip)) AS address_norm,
          n.tier, n.status, n.segment, n.join_date,
          year(n.join_date) AS join_year,
          datediff(n.join_date, DATE'1970-01-01') AS join_day,
          n.source_ids, n.updated_at
        FROM n LEFT JOIN al ON n.member_id = al.member_id
    """)


def build_search_docs():
    run_sql(f"""
        CREATE OR REPLACE TABLE {FQ}.member_search_doc
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        COMMENT 'Gold: one search document per member; source of the member AI Search index'
        AS
        SELECT
          member_id,
          full_name,
          concat_ws(' ',
            full_name, full_name_norm, name_phonetic, name_aliases,
            email_norm, email_local_alnum,
            phone_digits, phone_last4, phone_e164,
            city, state, zip, member_id, concat_ws(' ', source_ids),
            tier, status, segment
          ) AS search_text,
          email_norm AS email,
          phone_display AS phone,
          phone_e164, phone_last4,
          city, state, zip, tier, status, segment, join_year, join_day
        FROM {FQ}.member_golden
    """)


def build_interactions():
    run_sql(f"""
        CREATE OR REPLACE TABLE {FQ}.member_interactions
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        COMMENT 'Gold: notes and cases as searchable chunks; source of the interaction AI Search index'
        AS
        SELECT interaction_id, member_id, source_type, source_id, title, chunk_text,
               channel, category, sentiment, case_status, state, tier,
               CAST(created_at AS TIMESTAMP) AS created_at,  -- AI Search does not support timestamp_ntz
               datediff(CAST(created_at AS DATE), DATE'1970-01-01') AS created_day
        FROM (
          SELECT n.note_id AS interaction_id, n.member_id, 'note' AS source_type, n.note_id AS source_id,
                 concat('Contact note: ', replace(n.category, '_', ' ')) AS title,
                 concat('Contact note (', n.channel, ', ', replace(n.category, '_', ' '), '): ', n.note_text) AS chunk_text,
                 n.channel, n.category, n.sentiment, CAST(NULL AS STRING) AS case_status,
                 g.state, g.tier, n.created_at
          FROM {FQ}.member_notes n JOIN {FQ}.member_golden g USING (member_id)
          UNION ALL
          SELECT c.case_id, c.member_id, 'case', c.case_id,
                 concat('Case: ', c.subject) AS title,
                 concat('Case (', replace(c.category, '_', ' '), ', ', c.status, '): ', c.subject, '. ', c.description,
                        CASE WHEN c.resolution IS NULL THEN ' Status: still open.' ELSE concat(' Resolution: ', c.resolution) END) AS chunk_text,
                 c.channel, c.category,
                 CASE WHEN c.category IN ('billing_dispute','fraud_alert','service_outage','delivery_delay','cancellation_request') THEN 'negative' ELSE 'neutral' END AS sentiment,
                 c.status AS case_status, g.state, g.tier, c.opened_at AS created_at
          FROM {FQ}.member_cases c JOIN {FQ}.member_golden g USING (member_id)
        )
    """)


def build_profile():
    run_sql(f"""
        CREATE OR REPLACE TABLE {FQ}.member_profile
        COMMENT 'Gold: 360 aggregates per member, served by warehouse point reads'
        AS
        WITH o AS (
          SELECT member_id, count(*) AS order_count, round(sum(amount), 2) AS lifetime_value,
                 sum(CASE WHEN order_date >= DATE'2025-11-20' THEN 1 ELSE 0 END) AS orders_12m,
                 max(order_date) AS last_order_date
          FROM {FQ}.member_orders WHERE status <> 'cancelled' GROUP BY member_id
        ),
        c AS (
          SELECT member_id, count(*) AS total_cases,
                 sum(CASE WHEN status = 'open' THEN 1 ELSE 0 END) AS open_cases,
                 max(opened_at) AS last_case_at,
                 max_by(category, opened_at) AS latest_case_category
          FROM {FQ}.member_cases GROUP BY member_id
        ),
        n AS (
          SELECT member_id, count(*) AS note_count, max(created_at) AS last_contact_at,
                 sum(CASE WHEN sentiment = 'negative' AND created_at >= TIMESTAMP'2026-08-22' THEN 1 ELSE 0 END) AS negative_contacts_90d
          FROM {FQ}.member_notes GROUP BY member_id
        )
        SELECT g.member_id,
               coalesce(o.order_count, 0) AS order_count,
               coalesce(o.lifetime_value, 0.0) AS lifetime_value,
               coalesce(o.orders_12m, 0) AS orders_12m,
               o.last_order_date,
               coalesce(c.total_cases, 0) AS total_cases,
               coalesce(c.open_cases, 0) AS open_cases,
               c.latest_case_category,
               coalesce(n.note_count, 0) AS note_count,
               n.last_contact_at,
               coalesce(n.negative_contacts_90d, 0) AS negative_contacts_90d,
               CASE WHEN coalesce(c.open_cases,0) >= 1 AND coalesce(n.negative_contacts_90d,0) >= 2 THEN 'at_risk'
                    WHEN coalesce(n.negative_contacts_90d,0) >= 1 OR coalesce(c.open_cases,0) >= 1 THEN 'watch'
                    ELSE 'healthy' END AS health
        FROM {FQ}.member_golden g
        LEFT JOIN o USING (member_id) LEFT JOIN c USING (member_id) LEFT JOIN n USING (member_id)
    """)


def build_audit():
    run_sql(f"""
        CREATE TABLE IF NOT EXISTS {FQ}.search_events (
          event_id STRING, event_ts TIMESTAMP, user_email STRING, query_text STRING, intent STRING,
          parsed_json STRING, engines STRING, result_count INT, latency_ms INT
        ) COMMENT 'Audit log of every search issued from the Customer 360 app'
    """)


def validate():
    for t in ["members_source", "member_golden", "member_search_doc", "member_interactions", "member_profile",
              "member_orders", "member_cases", "member_notes", "first_name_aliases", "ref_nicknames"]:
        n = run_sql(f"SELECT count(*) FROM {FQ}.{t}", quiet=True)[0][0]
        print(f"  {t:22s} {int(n):>8,d}")
    print("\nSample golden rows:")
    for r in run_sql(f"""SELECT member_id, full_name, full_name_norm, name_phonetic, name_aliases, email_norm, phone_e164, phone_last4
                         FROM {FQ}.member_golden WHERE member_id IN ('M10000000','M10000002','M10000007','M10000009')""", quiet=True):
        print("  ", r)


def create_container():
    """Schema and staging volume (idempotent). The catalog must already exist and you need CREATE SCHEMA on it."""
    run_sql(f"CREATE SCHEMA IF NOT EXISTS {FQ} COMMENT 'Customer 360 member search demo (synthetic data)'")
    run_sql(f"CREATE VOLUME IF NOT EXISTS {FQ}.{config.VOLUME} COMMENT 'Staging area for the synthetic parquet files'")


def main():
    print("0/6 schema + volume");     create_container()
    print("1/6 upload files");        upload()
    print("2/6 load raw tables");     load_raw()
    print("3/6 member_golden");       build_golden()
    print("4/6 search docs + interactions"); build_search_docs(); build_interactions()
    print("5/6 profile + audit");     build_profile(); build_audit()
    print("6/6 validate");            validate()


if __name__ == "__main__":
    main()
