# Customer 360 Member Search on Databricks — Architecture Reference

Status: Agreed direction for review (no code yet)
Date: Nov 16, 2026
Decisions locked:
- **Search:** Databricks AI Search + LLM natural-language parser
- **App:** React + FastAPI on Databricks Apps
- **Out of scope:** Lakebase / Postgres serving

---

## 1. Problem statement

The customer's portal has a single search bar. Behind it, regex or `LIKE` queries run against Databricks tables. Business users want to find members by name, email, phone, member ID, address, and other attributes. Today's pain points:

- **No typo tolerance.** "Jon Smyth" doesn't find "John Smith"; "jsmith@gmail" misses "j.smith@gmail.com".
- **Format sensitivity.** "(555) 123-4567", "555.123.4567", and "+15551234567" are treated as different values.
- **No relevance ranking.** Results come back unordered or ordered by an arbitrary column.
- **Latency.** Regex scans on a SQL warehouse take seconds; typeahead isn't possible.
- **No 360 view.** Search returns rows, not a unified member profile with interactions, cases, claims, and orders.

Goal: a Databricks App (React + FastAPI) as the Customer 360 front end. Fast, ranked member search with optional natural-language queries, on governed lakehouse data — **without Lakebase**.

---

## 2. Agreed approach: AI Search + LLM parser (no Lakebase)

**Yes — AI Search is the right primary engine for this path**, with an LLM query parser in the FastAPI backend and a Serverless SQL Warehouse for exact lookups and profile serving.

| Search pattern | Example | How we handle it (no Lakebase) |
|---|---|---|
| Exact identifier / email / phone | `M123`, exact email, E.164 phone | **Filters** on AI Search metadata, or **point lookup** via Serverless SQL Warehouse on Gold |
| Keyword across many fields | "smith dallas gold" | **AI Search `FULL_TEXT` or `HYBRID`** on a denormalized search document |
| Typo / nickname names | "Jon Smyth", "Bob" → Robert | **Search document enrichment** (phonetic tokens, nickname aliases) + **LLM query rewrite** + hybrid |
| Partial phone / email | last 4 digits, local-part | **Normalized columns** in the index (`phone_last4`, `email_local`) + filters / keyword |
| Semantic over notes/cases | "complained about billing delays" | **AI Search `HYBRID` + reranker** on interaction chunks |
| Natural-language criteria | "gold members in Ohio who joined in 2025" | **LLM parser** → JSON filters + optional free-text → AI Search |
| Analytical questions (optional) | "how many members churned…" | **Genie** Conversation API (separate path; not v1-critical) |
| 360 profile read | open member card | **Serverless SQL Warehouse** `SELECT` by `member_id` from Gold |

### Why this works without Lakebase

Lakebase's advantage is character-level fuzzy matching (`pg_trgm`) and sub-50ms typeahead. We compensate with:

1. **Aggressive normalization and enrichment in Gold** so BM25/hybrid has the right tokens to match.
2. **LLM query rewrite** that expands typos, nicknames, and phone formats before search.
3. **Hybrid + reranker** for relevance when queries mix identifiers and prose.
4. **Serverless SQL** for exact ID/email/phone and for serving the profile page (point reads are fine; we are not doing warehouse-side regex scans for search).

### Honest trade-offs vs Lakebase

| Concern | Impact | Mitigation |
|---|---|---|
| Character-level typos ("Smyth"/"Smith") | BM25 is token-based; may miss without help | Phonetic tokens in doc + LLM rewrite + nickname table |
| Typeahead p95 | Higher than Postgres (typically tens–low hundreds of ms) | Debounce, `FULL_TEXT` only for typeahead, small `num_results`, no LLM on keystroke |
| Profile read latency | Warehouse point-get vs Postgres | Serverless SQL + small Gold profile table; cache hot profiles in app memory if needed |
| Ops surface | One less system (good) | All search traffic on AI Search endpoint + warehouse |

---

## 3. Databricks building blocks

| Capability | Component | Role |
|---|---|---|
| Ingestion / curation | Lakeflow Connect, Declarative Pipelines | Bronze → Silver → Gold |
| Identity resolution | Splink / Zingg / rules | Golden member record |
| Governance | Unity Catalog (tags, lineage, row filters, column masks) | PII, access, audit |
| Member + interaction search | **Databricks AI Search** (Delta Sync Index: hybrid + full-text + reranker) | Primary retrieval |
| Exact / profile reads | **Serverless SQL Warehouse** | Point lookup by `member_id`, email_norm, phone_e164 |
| NL understanding | **Foundation Model API** (LLM) | Intent detect, filter parse, query rewrite |
| Embeddings | Foundation Model / Databricks-managed embeddings on the index | Semantic channel of hybrid |
| Analytics (optional) | Genie Conversation API | "How many…" questions |
| Application | **Databricks Apps — React + FastAPI** | UI, query router, auth, audit |
| Observability | MLflow Tracing, AI Search query payload logging, system tables | Quality, latency, compliance |

---

## 4. Reference architecture

```mermaid
flowchart LR
    subgraph Sources["Source systems"]
        CRM[CRM / Member master]
        BILL[Billing / Orders]
        CC[Contact center<br/>notes & transcripts]
        CASE[Cases / Tickets]
        WEB[Digital / Web events]
    end

    subgraph Lakehouse["Databricks Lakehouse (Unity Catalog)"]
        direction TB
        BRZ[(Bronze)]
        SLV[(Silver<br/>cleansed + standardized)]
        ER[Identity resolution]
        GLD_M[(Gold: member_golden)]
        GLD_S[(Gold: member_search_doc<br/>enriched text + phonetic + aliases)]
        GLD_I[(Gold: member_interactions<br/>chunked notes/cases)]
        GLD_P[(Gold: member_profile<br/>360 aggregates)]
        BRZ --> SLV --> ER --> GLD_M
        GLD_M --> GLD_S
        GLD_M --> GLD_P
        SLV --> GLD_I
    end

    subgraph Serving["Serving"]
        AIS_M[(AI Search index<br/>members — hybrid/full-text)]
        AIS_I[(AI Search index<br/>interactions — hybrid + reranker)]
        WH[Serverless SQL Warehouse]
        FM[Foundation Model API<br/>LLM parser + rewrite]
        GENIE[Genie space<br/>optional]
    end

    subgraph App["Databricks App"]
        UI[React UI<br/>search, filters, 360 profile]
        API[FastAPI<br/>Query Router]
        AUD[(search_events Delta)]
        UI --> API
        API --> AUD
    end

    Sources --> BRZ
    GLD_S -- Delta Sync --> AIS_M
    GLD_I -- Delta Sync --> AIS_I
    GLD_M --> WH
    GLD_P --> WH
    API -- typeahead / keyword / hybrid --> AIS_M
    API -- semantic unstructured --> AIS_I
    API -- exact + profile --> WH
    API -- NL parse / rewrite --> FM
    API -. analytical .-> GENIE
    GENIE -. SQL .-> WH

    USERS([Business users]) -- SSO --> UI
    PORTAL([Existing portal]) -- REST --> API
```

Notes:
- Same FastAPI router is exposed as REST so the existing customer portal can call it without replacing their UI on day one.
- Two AI Search indexes keep member lookup lean (typeahead-friendly) and interaction search rich (chunks + reranker).

---

## 5. Data design

### 5.1 Gold `member_golden`

| Column | Purpose |
|---|---|
| `member_id` | Primary key |
| `first_name`, `last_name`, `full_name` | Display |
| `full_name_norm` | Lowercase, accents/punctuation stripped |
| `name_phonetic` | Double Metaphone / Soundex tokens (space-separated) |
| `name_aliases` | Nickname expansions (Bob→Robert, Kate→Katherine) |
| `email`, `email_norm`, `email_local`, `email_domain` | Exact + partial |
| `phone_e164`, `phone_digits`, `phone_last4` | Format-insensitive + suffix |
| `dob`, `address_norm`, `city`, `state`, `zip` | Filters / disambiguation |
| `tier`, `status`, `segment`, `join_date` | Facets |
| `source_ids` | Legacy system IDs |
| `updated_at` | Sync / freshness |

Normalization in the pipeline is the biggest quality win — do it once, not with regex at query time.

### 5.2 Gold `member_search_doc` (source for member AI Search index)

One row per member. Build a single `search_text` (and optional embedding source) that concatenates:

- display name + normalized name
- phonetic codes
- nickname aliases
- email_norm + email_local
- phone_digits + phone_last4 + phone_e164
- city / state / zip
- member_id + source_ids
- tier / status / segment (as tokens)

**Metadata columns** on the index (filterable, not necessarily embedded): `member_id`, `state`, `tier`, `status`, `segment`, `join_date`, `email_norm`, `phone_e164`, `phone_last4`.

Index mode: **Hybrid** (vector + BM25). Typeahead queries use `query_type=FULL_TEXT` for speed; full searches use `HYBRID` and optionally the **reranker**.

### 5.3 Gold `member_interactions` (source for interaction AI Search index)

Chunked notes / cases / transcripts with metadata: `member_id`, `channel`, `created_at`, `sentiment`, `state`, `tier`. Enable CDF; Delta Sync with Databricks-managed embeddings. Query with `HYBRID` + reranker; aggregate hits to distinct `member_id`s for the results list.

### 5.4 Gold `member_profile`

Wide or nested profile for the 360 page (demographics, open cases, last N interactions summary, orders/claims rollups). Served only via warehouse `WHERE member_id = ?` after search returns IDs — never scanned for search.

---

## 6. Query router (FastAPI)

One search box + advanced filter panel. LLM is used for **intent + rewrite + filter parse**, not on every typeahead keystroke.

```mermaid
flowchart TD
    Q[User query + optional UI filters] --> T{Typeahead?}
    T -- yes --> FT[AI Search FULL_TEXT<br/>members index, num_results=10<br/>no LLM]
    T -- no --> D{Intent via rules + LLM}

    D -- email-like --> E[Normalize → filter email_norm<br/>or FULL_TEXT on email tokens]
    D -- phone-like --> P[Normalize E.164 / digits<br/>→ filter phone_e164 or phone_last4]
    D -- ID-like --> I[Filter member_id / source_ids<br/>or warehouse exact]
    D -- name / free text --> N[LLM rewrite: expand nicknames,<br/>phonetics, fix likely typos<br/>→ HYBRID members index]
    D -- descriptive / notes --> S[HYBRID + reranker on<br/>interactions → group by member_id]
    D -- NL with criteria --> L[LLM → JSON filters + query_text<br/>→ HYBRID members ± interactions]
    D -- analytical --> G[Genie — optional]

    FT & E & P & I & N & S & L --> R[Merge / dedupe by member_id<br/>rank + match-reason badges]
    R --> UI[Results → profile via warehouse]
```

### LLM parser contract (illustrative)

Input: raw query + optional UI facets.  
Output JSON, for example:

```json
{
  "intent": "member_lookup | interaction_search | filtered_nl | analytical",
  "query_text": "john smith",
  "query_rewrites": ["john smith", "jon smith", "jonathan smith"],
  "filters": {
    "state": ["OH"],
    "tier": ["gold"],
    "join_date_gte": "2025-01-01"
  },
  "phone_last4": null,
  "email_norm": null,
  "member_id": null
}
```

Backend applies filters as AI Search metadata filters (never trust client-only filters for authorization). Multiple rewrites can be issued and fused (RRF) if needed.

### Ranking UX

- Exact ID / email / phone hits boosted to top.
- Show **match-reason badges** ("name hybrid", "phone last4", "note: billing complaint").
- Profile open: FastAPI → warehouse by `member_id` → return 360 payload.

---

## 7. Option comparison (updated for locked decisions)

| | Improved SQL only | AI Search only | **Chosen: AI Search + LLM** | Lakebase path (rejected) |
|---|---|---|---|---|
| Fuzzy names | Weak | Medium | **Stronger** (enrichment + rewrite) | Strongest (trigram) |
| Phone / email | Scans | Medium with norm columns | **Good** with norm + filters | Strongest |
| Typeahead | Poor | Good | **Good** (FULL_TEXT, no LLM) | Best |
| Unstructured semantic | Poor / expensive | Strong | **Strong** | DIY |
| NL criteria | Genie / custom | No | **Yes (LLM)** | No (unless added) |
| 360 profile | Warehouse | N/A | **Warehouse** | Postgres |
| Customer constraint | — | — | **Meets no-Lakebase** | Violates |

---

## 8. Security and governance (PII)

- **Auth:** Databricks Apps SSO. Prefer **on-behalf-of-user** where Unity Catalog row filters / column masks must apply on warehouse profile reads. For AI Search, inject **server-side** metadata filters that encode the user's scope (region / LOB); never take authorization filters from the client alone.
- **AI Search ACLs:** endpoint + index permissions; sync only columns needed for search/display.
- **PII minimization:** mask SSN / DOB / full phone in result lists; reveal on profile with permission check + audit.
- **Audit:** every search → `search_events` (user, query, intent, result IDs, latency, timestamp). Restrict raw query text if HIPAA.
- **Check before build:** confirm current AI Search support/limitations when the source Delta table has UC row filters or column masks; if blocked, sync a pre-filtered / pre-masked Gold view into the index.

---

## 9. Non-functional targets (validate in POC)

| Metric | Target |
|---|---|
| Typeahead p95 | < 300 ms end to end (FULL_TEXT, no LLM) |
| Full member search p95 | < 800 ms (HYBRID; +reranker if used) |
| NL parsed search p95 | < 2.5 s (includes LLM parse) |
| Interaction semantic p95 | < 1.5 s with reranker |
| Profile load p95 | < 500 ms (warehouse point get) |
| Freshness | Minutes–hourly via Delta Sync (triggered or continuous per requirement) |
| Quality | Precision@5 / Recall@10 on ~100 labeled queries vs current regex baseline |

---

## 10. Demo / POC plan (aligned to decisions)

**Phase 0 — Discovery**
- Volume, concurrency, top attributes, 20–50 real queries (including failures)
- Unstructured notes/cases in scope? Regulatory (HIPAA/PCI/GDPR)? Replace portal vs API?
- Confirm AI Search + Apps + Serverless SQL availability in customer's cloud/region

**Phase 1 — Synthetic Gold**
- Synthetic members with typos, nicknames, multi-system IDs, mixed phone formats
- Build `member_golden`, `member_search_doc`, `member_interactions`, `member_profile`

**Phase 2 — AI Search + FastAPI router MVP**
- Two Delta Sync indexes (members hybrid; interactions hybrid)
- FastAPI: typeahead FULL_TEXT, exact filters, hybrid search, warehouse profile
- React: search bar, filters, results + match badges, 360 profile page

**Phase 3 — LLM natural-language layer**
- Intent / filter parse / query rewrite via Foundation Model API
- MLflow Tracing on parse + search
- Optional Genie panel later

**Phase 4 — Hardening**
- Auth scope filters, masking, audit, latency/quality bake-off vs regex baseline

---

## 11. Locked vs open decisions

| Topic | Status |
|---|---|
| Engine | **Locked:** AI Search + LLM NL parser; no Lakebase |
| Front end | **Locked:** React + FastAPI on Databricks Apps |
| Unstructured interactions in v1 demo | **Open** — recommend yes with synthetic notes (shows hybrid/reranker value) |
| Genie in v1 | **Open** — recommend defer; LLM filters cover most demo wow |
| Auth: app SP vs on-behalf-of-user | **Open** — recommend OBO if UC row filters matter for profiles |
| Existing portal integration | **Open** — recommend expose REST from day one either way |

---

## References

- Databricks AI Search: https://docs.databricks.com/aws/en/ai-search/ai-search
- Query AI Search (ANN / hybrid / full-text / reranker): https://docs.databricks.com/aws/en/ai-search/query-ai-search
- Create AI Search indexes: https://docs.databricks.com/aws/en/ai-search/create-ai-search
- `vector_search()` SQL: https://docs.databricks.com/aws/en/sql/language-manual/functions/vector_search
